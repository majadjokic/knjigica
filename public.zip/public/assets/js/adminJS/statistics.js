$(document).ready(()=>{
    localStorage.clear();
    //linkoni do generisanih json fajlova POCETAK
    $rasparcaj=window.location.href
    $rasparcano=$rasparcaj.split("/admin")
    $visitors=$rasparcano[0]+"/visitors"
    $orders=$rasparcano[0]+"/orders"
    $titles4orders=$rasparcano[0]+"/titles4orders"

    //linkoni do generisanih json fajlova KRAJ
    ucitajAjax($visitors,visitorsShow)
    ucitajAjax($orders,ordersShow)

    // getDateForVisits()

    document.getElementById('datumZaBrPoseta').addEventListener('change',getDateForVisits)
    document.getElementById('mesecZaBrKupovina').addEventListener('change',getMonthForOrders)
    document.getElementById('godinaZaBrKupovina').addEventListener('change',getYearForOrders)

})

function ucitajAjax(file, fun) {
    $.ajax({
        url: file,
        method: "GET",
        type: "json",
        success: (result) => {
            fun(JSON.parse(result));
        },
        error: (x) => {
            console.log(x);
        }
    })
}

function currentDate(){
    const date = new Date();
    var dan=date.getDate();
    var mesec=date.getMonth()+1;
    var godina=date.getFullYear();
    if(dan<10){
        dan="0"+dan
    }
    if(mesec<10){
        mesec="0"+mesec
    }

    var datum=dan+"."+mesec+"."+godina+"."

    return datum
}

function visitorsShow(result){
    var ispis=`
<table class="table table-responsive table-striped">
<thead>
    <tr>
        <th scope="col">Stranica</th>
        <th scope="col">Broj poseta</th>
    </tr>
    </thead>
    <tbody>`;

    var date="";
    var visDate=localStorage.getItem('visDate')
    if(visDate==null){
        date=currentDate();
    }
    else{
        date=visDate;
    }
    document.getElementById('infoDateVis').innerText="Trenutno se prikazuju informacije za datum: "+date
    var brRez=0
    for(let v of result){
        if(v.date==date){
            ispis+=`<tr>
                <td>${v.page}</td>
                <td>${v.number}</td>
            </tr>`
            brRez++
        }
    }
    ispis+=`</tbody>
            </table>`
    if(brRez!=0){
        document.getElementById('visitsTable').innerHTML=ispis;
    }
    else{
        document.getElementById('visitsTable').innerHTML=`<h2>Nema nista za ovaj datum</h2>`
    }

}

function ordersShow(result){
    const date = new Date();
    var ispis=`
<table class="table table-responsive table-striped">
<thead>
    <tr>
        <th scope="col">Datum korpe</th>
        <th scope="col">Ime kupca</th>
        <th>Knjige koje je kupio</th>
        <th scope="col">Adresa kupca</th>
        <th scope="col">Cena korpe</th>
    </tr>
    </thead>
    <tbody>`;

    var month="";
    var year="";
    var ordMonth=localStorage.getItem('ordMonth')
    var ordYear=localStorage.getItem('ordYear')
    if(ordMonth==null){
        month=date.getMonth()+1;
    }
    else{
        month=ordMonth;
    }
    if(ordYear==null){
        year=date.getFullYear();
    }
    else{
        year=ordYear;
    }

    if(month<10){
        month="0"+month
    }

    var datum=month+"."+year+"."
    document.getElementById('infoDateOrd').innerText="Trenutno se prikazuju informacije za: "+datum
    var brRez=0
    var zarada=0;


    for(let o of result){
        if(o.cart_date.includes(datum)){


            ispis+=`<tr>
                <td>${o.cart_date}</td>
                <td>${o.name}</td>
                <td id="knjige${o.cart_id}"></td>
                <td>${o.address}</td>
                <td>${o.price}</td>
            </tr>`

            var titles4orders = []
            knjige(o.cart_id, titles4orders)

            function knjige(korpa, niz) {
                $.ajax({
                    url: $titles4orders,
                    type: "json",
                    method: "GET",
                    success: (result) => {
                        var tit4ord = JSON.parse(result)
                        var c=korpa
                        var knjige = ""
                        var ct = niz
                        for (let t4o of tit4ord) {
                            if (t4o.cart_id == c) {
                                ct.push(t4o.title)
                            }
                        }
                        for (let x = 0; x < ct.length; x++) {
                            if (x < ct.length - 1) {
                                knjige += "'"+ct[x] +"'"+ ", "
                            } else {
                                knjige += "'"+ct[x] +"'"
                            }
                        }
                        var aaa = "knjige" + c
                        document.getElementById(aaa).innerHTML = knjige

                    }
                })
            }

            brRez++
            zarada+=parseInt(o.price)
            console.log(titles4orders)
        }
    }
    ispis+=`</tbody>
            </table>`
    if(brRez!=0){
        document.getElementById('brojKupovina').innerText="BROJ KUPOVINA: "+brRez
        document.getElementById('zaradaZaMesec').innerText="UKUPNA ZARADA ZA MESEC "+datum+" : "+zarada+" RSD"
        document.getElementById('ordersTable').innerHTML=ispis;
    }
    else{
        document.getElementById('brojKupovina').innerText=""
        document.getElementById('zaradaZaMesec').innerText=""
        document.getElementById('ordersTable').innerHTML=`<h2>Nema nista za ovaj mesec :(</h2>`
    }

}

function getDateForVisits(){
    var datiDatum=this.value
    var d=datiDatum.split('-')
    var noviDatum=d[2]+"."+d[1]+"."+d[0]+"."
    localStorage.setItem('visDate',noviDatum)
    ucitajAjax($visitors,visitorsShow)
}

function getMonthForOrders(){
    var datiMesec=this.value
    localStorage.setItem('ordMonth',datiMesec)
    ucitajAjax($orders,ordersShow)
}

function getYearForOrders(){
    var dataGodina=this.value
    localStorage.setItem('ordYear',dataGodina)
    ucitajAjax($orders,ordersShow)
}
