$(document).ready(()=>{
    localStorage.clear();
    //linkoni do generisanih json fajlova POCETAK
    $rasparcaj=window.location.href
    $rasparcano=$rasparcaj.split("/admin")
    $userAct=$rasparcano[0]+'/userActivities'
    $adminAct=$rasparcano[0]+'/adminActivities'

    ucitajAjax($userAct,getUserActivities)
    ucitajAjax($adminAct,getAdminActivities)

    document.getElementById('datumZaAktKor').addEventListener('change',getDateForUserActivities)
    document.getElementById('datumZaAktAdm').addEventListener('change',getDateForAdminActivities)

})

function ucitajAjax(file, fun) {
    $.ajax({
        url: file,
        method: "GET",
        type: "json",
        success: (result) => {
            fun(JSON.parse(result));
        },
        error: (x) => {
            console.log(x);
        }
    })
}

function currentDate(){
    const date = new Date();
    var dan=date.getDate();
    var mesec=date.getMonth()+1;
    var godina=date.getFullYear();
    if(dan<10){
        dan="0"+dan
    }
    if(mesec<10){
        mesec="0"+mesec
    }

    var datum=dan+"."+mesec+"."+godina+"."

    return datum
}

function getDateForUserActivities(){
    var datiDatum=this.value
    var d=datiDatum.split('-')
    var noviDatum=d[2]+"."+d[1]+"."+d[0]+"."
    localStorage.setItem('uActDate',noviDatum)
    ucitajAjax($userAct,getUserActivities)
}

function getDateForAdminActivities(){
    var datiDatum=this.value
    var d=datiDatum.split('-')
    var noviDatum=d[2]+"."+d[1]+"."+d[0]+"."
    localStorage.setItem('aActDate',noviDatum)
    ucitajAjax($adminAct,getAdminActivities)
}

function getUserActivities(result){

    var ispis=`
<table class="table table-responsive table-striped">
<thead>
    <tr>
        <th scope="col">Username</th>
        <th scope="col">Aktivnost</th>
        <th scope="col">Datum</th>
        <th scope="col">Vreme</th>
    </tr>
    </thead>
    <tbody>`;

    var date="";
    var uActDate=localStorage.getItem('uActDate')
    if(uActDate==null){
        date=currentDate();
    }
    else{
        date=uActDate;
    }
    document.getElementById('infoAktKor').innerText="Trenutno se prikazuju informacije za datum: "+date
    var brRez=0
    for(let ua of result){
        if(ua.date===date){
            ispis+=`<tr>
                <td>${ua.user_name}</td>
                <td>${ua.activity}</td>
                <td>${ua.date}</td>
                <td>${ua.time}</td>
            </tr>`
            brRez++
        }
    }
    ispis+=`</tbody>
            </table>`
    if(brRez!==0){
        document.getElementById('activitiesUsersTable').innerHTML=ispis;
    }
    else{
        document.getElementById('activitiesUsersTable').innerHTML=`<h2>Nema nista za ovaj datum</h2>`
    }


}

function getAdminActivities(result){

    var ispis=`
<table class="table table-responsive table-striped">
<thead>
    <tr>
        <th scope="col">Username</th>
        <th scope="col">Aktivnost</th>
        <th scope="col">Datum</th>
        <th scope="col">Vreme</th>
    </tr>
    </thead>
    <tbody>`;

    var date="";
    var aActDate=localStorage.getItem('aActDate')
    if(aActDate==null){
        date=currentDate();
    }
    else{
        date=aActDate;
    }
    document.getElementById('infoAktAdm').innerText="Trenutno se prikazuju informacije za datum: "+date
    var brRez=0
    for(let aa of result){
        if(aa.date===date){
            ispis+=`<tr>
                <td>${aa.user_name}</td>
                <td>${aa.activity}</td>
                <td>${aa.date}</td>
                <td>${aa.time}</td>
            </tr>`
            brRez++
        }
    }
    ispis+=`</tbody>
            </table>`
    if(brRez!==0){
        document.getElementById('activitiesAdminsTable').innerHTML=ispis;
    }
    else{
        document.getElementById('activitiesAdminsTable').innerHTML=`<h2>Nema nista za ovaj datum</h2>`
    }


}
