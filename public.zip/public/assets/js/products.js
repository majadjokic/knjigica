$(document).ready(()=>{

    localStorage.clear();

    //linkoni do generisanih json fajlova POCETAK
    $rasparcaj=window.location.href
    $rasparcano=$rasparcaj.split("/public")
    $titlesLink=$rasparcano[0]+"/public/titles"
    $authors4title=$rasparcano[0]+"/public/authors4title"
    $genres4title=$rasparcano[0]+"/public/genres4title"
    $authorsLink=$rasparcano[0]+"/public/authors"
    $genresLink=$rasparcano[0]+"/public/genres"
    //linkoni do generisanih json fajlova KRAJ


    //ucitavanje ajaxa POCETAK
    ucitajAjax($titlesLink,titles);
    ucitajAjax($authorsLink,authors);
    ucitajAjax($genresLink,genres);
    //ucitavanje ajaxa KRAJ

    //aktiviranje filtera
    $("#search").keyup(searchON);

    //filteri za zanrove i autore se aktiviraju u njihovim funkcijama za izpis podata iz baze
    //filteri se aktiviraju u f-jama za njihov ispis

    $('#sortiranje').change(sacuvajSort)
    oznaciSort()
    $('#ukloni').click(deleteAllSFS)


})

function deleteAllSFS(){
    $("#search").val("")
    localStorage.removeItem('genres')
    localStorage.removeItem('genreTitle')
    localStorage.removeItem('authors')
    localStorage.removeItem('authorTitle')
    localStorage.removeItem('sortBy')
    ucitajAjax($titlesLink,titles);
    oznaciZanrove()
    oznaciAutore()
    oznaciSort()
}

//funkcija za pokretanje prikaza svega
function ucitajAjax(file, fun) {
    $.ajax({
        url: file,
        method: "GET",
        type: "json",
        success: (result) => {
            fun(JSON.parse(result));
        },
        error: (x) => {
            console.log(x);
        }
    })
}



//naslovi tj galerija proizvoda POCETAK
{
    //prikaz proizvoda, filtriranje+sortiranje(ako ih ima)
    function titlesNoFilter(result) {
        var rasparcaj = window.location.href
        var rasparcano = rasparcaj.split("/public")
        var linkPocetak = rasparcano[0] + '/public/products/'

        var resJson = result
        // var resJson=JSON.parse(result)

        var ispis = "";
        for (let t of resJson) {
            ispis += `<div class="m-3 col-xl-3 col-lg-3 col-md-6 col-sm-8 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-3">
                <a href="` + linkPocetak + `${t.id}"><img
                    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"
                    src="assets/img/proizvodi/${t.cover}" alt="${t.title} cover"></a>
            </div>
            <h5 class="font-weight-bold">${t.title}</h5>
            <p id="autori${t.id}">
                `
            var nizAutora = []
            pisci(t.id, nizAutora)

            function pisci(naslov, niz) {
                $.ajax({
                    url: $authors4title,
                    type: "json",
                    method: "GET",
                    success: (result) => {
                        var sviAutori = JSON.parse(result)
                        var n = naslov
                        var autori = ""
                        var na = niz
                        for (let a of sviAutori) {
                            if (a.title_id == n) {
                                na.push(a.author)
                            }
                        }
                        for (let x = 0; x < na.length; x++) {
                            if (x < na.length - 1) {
                                autori += na[x] + ", "
                            } else {
                                autori += na[x]
                            }
                        }
                        var aaa = "autori" + n
                        document.getElementById(aaa).innerHTML = autori

                    }
                })
            }

            ispis += `
            </p>
            <div id="cena${t.id}">
                <h4>${t.price} RSD</h4>
            </div>

        </div>`
        }


        document.getElementById("products").innerHTML = ispis;

    }

    function titles(result) {
        var rasparcaj = window.location.href
        var rasparcano = rasparcaj.split("/public")
        var linkPocetak = rasparcano[0] + '/public/products/'

        var resJson = result

        //uzima i pravi ls-ove sa naslovima koji imaju te zanrove i autore

        var genresExist=false
        var authorsExist=false
        //uzmi podatke iz ls koji se koriste za filtriranje
        var genreTitleLs=localStorage.getItem('genreTitle')
        if(genreTitleLs!=null&&genreTitleLs.length!=0){
            var genreTitleNum=[]
            genreTitleLs = localStorage.getItem('genreTitle').split(',')
            // console.log(genreTitleLs)
            for (let gt of genreTitleLs) {
                genreTitleNum.push(parseInt(gt))
            }
            console.log('genreTitleNum dole')
            console.log(genreTitleNum)
            genresExist=true
        }
        else{
            genresExist=false
        }

        var authorTitleLs=localStorage.getItem('authorTitle')
        if(authorTitleLs!=null&&authorTitleLs.length!=0){
            // console.log(authorTitleLs.length)
            var authorTitleNum=[]
            authorTitleLs = localStorage.getItem('authorTitle').split(',')
            for (let at of authorTitleLs) {
                authorTitleNum.push(parseInt(at))
            }
            authorsExist=true
            console.log(authorTitleNum)
        }
        else{
            authorsExist=false
        }

        //pravljenje niza pokome se prikazuju naslovi
        var titlesFiltered=[]

        //provera da li ima sortiranja

        var sortExists=false

        var sortBy=localStorage.getItem('sortBy')

        if(sortBy!=null){
            sortExists=true
        }
        else{
            sortExists=false
        }


        if(genresExist==true&&authorsExist==true){

            //filtrira sa akcentom na autora
            // for(let at of authorTitleNum){
            //     if(genreTitleNum.includes(at)){
            //         titlesFiltered.push(at)
            //     }
            // }

            //filtrira bez akcenta na bilo koga
            for(let at of authorTitleNum){
                titlesFiltered.push(at)
            }
            for(let gt of genreTitleNum){
                titlesFiltered.push(gt)
            }

            const distinct = (value, index, self) => {
                return self.indexOf(value) === index;
            }
            titlesFiltered= titlesFiltered.filter(distinct)
        }
        else if(genresExist==true&&authorsExist==false){
            titlesFiltered=genreTitleNum
        }
        else if(genresExist==false&&authorsExist==true){
            titlesFiltered=authorTitleNum
        }
        else if(genresExist==false&&authorsExist==false){
            titlesFiltered="nema filtera"
        }
        // console.log("genresExist: "+genresExist)
        // console.log("authorsExist: "+authorsExist)
        // console.log('titlesFiltered dole')
        // console.log(titlesFiltered)
        var ispis = "";
        if(titlesFiltered==="nema filtera" && sortExists==false){
            console.log("iz no filter no sort (titlesFltered): "+titlesFiltered)
            console.log("iz no filter no sort (sortBy): "+sortBy)
            ucitajAjax($titlesLink,titlesNoFiltersSorting)
        }
        else if(titlesFiltered!=="nema filtera" && sortExists==false){
            // var ispis = "";
            // console.log(titlesFiltered.length)
            console.log("iz yes filter no sort (titlesFltered): "+titlesFiltered)
            console.log("iz yes filter no sort (sortBy): "+sortBy)
            if(titlesFiltered.length!=0){
                for (let t of resJson) {
                    if(titlesFiltered.includes(t.id)){
                        ispis += `<div class="m-3 col-xl-3 col-lg-3 col-md-6 col-sm-8 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-3">
                <a href="` + linkPocetak + `${t.id}"><img
                    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"
                    src="assets/img/proizvodi/${t.cover}" alt="${t.title} cover"></a>
            </div>
            <h5 class="font-weight-bold">${t.title}</h5>
            <p id="autori${t.id}">
                `
                        var nizAutora = []
                        pisci(t.id, nizAutora)

                        function pisci(naslov, niz) {
                            $.ajax({
                                url: $authors4title,
                                type: "json",
                                method: "GET",
                                success: (result) => {
                                    var sviAutori = JSON.parse(result)
                                    var n = naslov
                                    var autori = ""
                                    var na = niz
                                    for (let a of sviAutori) {
                                        if (a.title_id == n) {
                                            na.push(a.author)
                                        }
                                    }
                                    for (let x = 0; x < na.length; x++) {
                                        if (x < na.length - 1) {
                                            autori += na[x] + ", "
                                        } else {
                                            autori += na[x]
                                        }
                                    }
                                    var aaa = "autori" + n
                                    document.getElementById(aaa).innerHTML = autori

                                }
                            })

                        }

                        ispis += `
            </p>
            <div id="cena${t.id}">
                <h4>${t.price} RSD</h4>
            </div>

        </div>`
                    }
                }
            }
            else{
                ispis=`<h1>Nema naslova za prikaz :(</h1>`
            }


            document.getElementById("products").innerHTML = ispis;
        }
        else if(titlesFiltered!=="nema filtera" && sortExists==true){
            resJson.sort((a, b) => {
                if (sortBy == "az") {
                    return a.title > b.title ? 1 : -1;
                } else if (sortBy == "za") {
                    return b.title > a.title ? 1 : -1;
                }
                if (sortBy == "asc") {
                    return a.price > b.price ? 1 : -1;
                } else if (sortBy == "desc") {
                    return b.price > a.price ? 1 : -1;
                } else {
                    return 0;
                }
            })
            console.log("iz yes filter yes sort (titlesFltered): "+titlesFiltered)
            console.log("iz yes filter yes sort (sortBy): "+sortBy)

            // console.log(titlesFiltered.length)

            if(titlesFiltered.length!=0){
                for (let t of resJson) {
                    if(titlesFiltered.includes(t.id)){
                        ispis += `<div class="m-3 col-xl-3 col-lg-3 col-md-6 col-sm-8 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-3">
                <a href="` + linkPocetak + `${t.id}"><img
                    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"
                    src="assets/img/proizvodi/${t.cover}" alt="${t.title} cover"></a>
            </div>
            <h5 class="font-weight-bold">${t.title}</h5>
            <p id="autori${t.id}">
                `
                        var nizAutora = []
                        pisci(t.id, nizAutora)

                        function pisci(naslov, niz) {
                            $.ajax({
                                url: $authors4title,
                                type: "json",
                                method: "GET",
                                success: (result) => {
                                    var sviAutori = JSON.parse(result)
                                    var n = naslov
                                    var autori = ""
                                    var na = niz
                                    for (let a of sviAutori) {
                                        if (a.title_id == n) {
                                            na.push(a.author)
                                        }
                                    }
                                    for (let x = 0; x < na.length; x++) {
                                        if (x < na.length - 1) {
                                            autori += na[x] + ", "
                                        } else {
                                            autori += na[x]
                                        }
                                    }
                                    var aaa = "autori" + n
                                    document.getElementById(aaa).innerHTML = autori

                                }
                            })

                        }

                        ispis += `
            </p>
            <div id="cena${t.id}">
                <h4>${t.price} RSD</h4>
            </div>

        </div>`
                    }
                }
            }
            else{
                ispis=`<h1>Nema naslova za prikaz :(</h1>`
            }


            document.getElementById("products").innerHTML = ispis;
        }
        else if(titlesFiltered==="nema filtera" && sortExists==true){
            resJson.sort((a, b) => {
                if (sortBy == "az") {
                    return a.title > b.title ? 1 : -1;
                } else if (sortBy == "za") {
                    return b.title > a.title ? 1 : -1;
                }
                if (sortBy == "asc") {
                    return a.price > b.price ? 1 : -1;
                } else if (sortBy == "desc") {
                    return b.price > a.price ? 1 : -1;
                } else {
                    return 0;
                }
            })
            console.log("iz no filter yes sort (titlesFltered): "+titlesFiltered)
            console.log("iz no filter yes sort (sortBy): "+sortBy)
            for (let t of resJson) {
                ispis += `<div class="m-3 col-xl-3 col-lg-3 col-md-6 col-sm-8 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-3">
                <a href="` + linkPocetak + `${t.id}"><img
                    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"
                    src="assets/img/proizvodi/${t.cover}" alt="${t.title} cover"></a>
            </div>
            <h5 class="font-weight-bold">${t.title}</h5>
            <p id="autori${t.id}">
                `
                var nizAutora = []
                pisci(t.id, nizAutora)

                function pisci(naslov, niz) {
                    $.ajax({
                        url: $authors4title,
                        type: "json",
                        method: "GET",
                        success: (result) => {
                            var sviAutori = JSON.parse(result)
                            var n = naslov
                            var autori = ""
                            var na = niz
                            for (let a of sviAutori) {
                                if (a.title_id == n) {
                                    na.push(a.author)
                                }
                            }
                            for (let x = 0; x < na.length; x++) {
                                if (x < na.length - 1) {
                                    autori += na[x] + ", "
                                } else {
                                    autori += na[x]
                                }
                            }
                            var aaa = "autori" + n
                            document.getElementById(aaa).innerHTML = autori

                        }
                    })

                }

                ispis += `
            </p>
            <div id="cena${t.id}">
                <h4>${t.price} RSD</h4>
            </div>

        </div>`
            }


            document.getElementById("products").innerHTML = ispis;

        }



    }

    function getFilteredGenres(){

        //zanrovi
        var genresLs=localStorage.getItem('genres')
        var genresFilter=[]
        if(genresLs!=null){
            genresLs=genresLs.split(',')
            for(let g of genresLs){
                genresFilter.push(parseInt(g))
                //parseInt()
            }
            // console.log(genresFilter)
        }

        $.ajax({
            url: $genres4title,
            method: "GET",
            type: "json",
            success: (result) => {
                var genresTitles=JSON.parse(result)
                var genreTitle=[]
                for(let gt of genresTitles){
                    // console.log(genresFilter)
                    // console.log(typeof (gt.genre_id))
                    if(genresFilter.includes(gt.genre_id)){
                        genreTitle.push(gt.title_id)
                        // console.log(gt.genre_id)
                    }
                }
                // console.log(genreTitle)
                const distinct = (value, index, self) => {
                    return self.indexOf(value) === index;
                }
                genreTitle= genreTitle.filter(distinct)
                // console.log(genreTitle)
                localStorage.setItem('genreTitle', genreTitle)
                ucitajAjax($titlesLink,titles)
            },
            error: (x) => {
                console.log(x);
            }
        })

    }

    function getFilteredAuthors(){
        //autori

        var authorsLs=localStorage.getItem('authors')
        var authorsFilter=[]
        if(authorsLs!=null){
            authorsLs=authorsLs.split(',')
            for(let a of authorsLs){
                authorsFilter.push(parseInt(a))
                //parseInt()
            }
            // console.log(authorsFilter)
        }

        $.ajax({
            url: $authors4title,
            method: "GET",
            type: "json",
            success: (result) => {
                var authorsTitles=JSON.parse(result)
                var authorTitle=[]
                for(let at of authorsTitles){
                    // console.log(genresFilter)
                    // console.log(typeof (gt.genre_id))
                    if(authorsFilter.includes(at.author_id)){
                        authorTitle.push(at.title_id)
                        // console.log(gt.genre_id)
                    }
                }
                // console.log(authorTitle)
                const distinct = (value, index, self) => {
                    return self.indexOf(value) === index;
                }
                authorTitle= authorTitle.filter(distinct)
                // console.log(authorTitle)
                localStorage.setItem('authorTitle', authorTitle)
                ucitajAjax($titlesLink,titles)
            },
            error: (x) => {
                console.log(x);
            }
        })
    }
}
//naslovi tj galerija proizvoda KRAJ

//samo za prikaz POCETAK
{
    function authors(result) {
        var ispis = ""
        var resJson = result
        // var resJson=JSON.parse(result)
        for (let a of resJson) {
            ispis += `<div>
<input class="form-check-input author" type="checkbox" name="authors[]" id="author${a.id}" value=${a.id}>
<label class="form-check-label" for=${a.id}>
                                        ${a.author}
                                    </label>
</div>`
        }
        document.getElementById('filteriAutori').innerHTML = ispis

        oznaciAutore()
        aktivirajAutore()
    }

    function genres(result) {
        var ispis = ""
        var resJson = result
        // var resJson=JSON.parse(result)
        for (let g of resJson) {
            ispis += `<div>
<input class="genre form-check-input " type="checkbox" name="genres[]" id="genre${g.id}" value=${g.id}>
<label class="form-check-label" for="genre${g.id}">
                                        ${g.genre}
                                    </label>
</div>`
        }
        document.getElementById('filteriZanrovi').innerHTML = ispis

        oznaciZanrove()
        aktivirajZanrove()
    }
}
//samo za prikaz KRAJ


//search POCETAK
{
    function searchON() {
        ucitajAjax($titlesLink, search)
    }

    function search(prod) {
        var unos = document.getElementById("search").value
        // var pp=JSON.parse(prod)
        var p = prod.filter((x) => {
            if (x.title.toLowerCase().indexOf(unos.trim().toLowerCase()) != -1) {
                return x;
            }
        })
        titlesNoFiltersSorting(p)
    }

    function titlesNoFiltersSorting(result) {
        var rasparcaj = window.location.href
        var rasparcano = rasparcaj.split("/public")
        console.log(rasparcano)
        console.log(rasparcano[0])
        var linkPocetak = rasparcano[0] + '/public/products/'

        var resJson = result
        var ispis = "";
        // var resJson=JSON.parse(result)
        if (resJson.length != 0) {
            for (let t of resJson) {
                ispis += `<div class="m-3 col-xl-3 col-lg-3 col-md-6 col-sm-8 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-3">
                <a href="` + linkPocetak + `${t.id}"><img
                    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"
                    src="assets/img/proizvodi/${t.cover}" alt="${t.title} cover"></a>
            </div>
            <h5 class="font-weight-bold">${t.title}</h5>
            <p id="autori${t.id}">
                `
                var nizAutora = []
                pisci(t.id, nizAutora)

                function pisci(naslov, niz) {
                    $.ajax({
                        url: $authors4title,
                        type: "json",
                        method: "GET",
                        success: (result) => {
                            var sviAutori = JSON.parse(result)
                            var n = naslov
                            var autori = ""
                            var na = niz
                            for (let a of sviAutori) {
                                if (a.title_id == n) {
                                    na.push(a.author)
                                }
                            }
                            for (let x = 0; x < na.length; x++) {
                                if (x < na.length - 1) {
                                    autori += na[x] + ", "
                                } else {
                                    autori += na[x]
                                }
                            }
                            var aaa = "autori" + n
                            document.getElementById(aaa).innerHTML = autori

                        }
                    })

                }

                ispis += `
            </p>
            <div id="cena${t.id}">
                <h4>${t.price} RSD</h4>
            </div>

        </div>`
            }
        } else {
            ispis = `<h1>Nema proizvoda za prikaz :(</h1>`
        }


        document.getElementById("products").innerHTML = ispis;

    }
}
//search KRAJ

//zanrovi filter POCETAK
{
    function oznaciZanrove(){
        var genresToCheckLs = localStorage.getItem('genres')
        console.log('genToCheckLs: '+genresToCheckLs)
        var genresToCheck = []
        var allGenres = document.getElementsByClassName('genre')
        if(genresToCheckLs!=null){
            genresToCheckLs = localStorage.getItem('genres').split(',')
            for (let i = 0; i < genresToCheckLs.length; i++) {
                // ako se buni dodaj parse int
                genresToCheck.push(genresToCheckLs[i])
            }
            for (let i = 0; i < allGenres.length; i++) {
                if (genresToCheck.includes(allGenres[i].value)) {
                    allGenres[i].checked = true;
                }
            }
        }else{
            console.log('hi false')
            for (let i = 0; i < allGenres.length; i++) {
                allGenres[i].checked = false;
            }
        }

    }

    function aktivirajZanrove() {
        var el = document.getElementsByClassName('genre')
        for (let i = 0; i < el.length; i++) {
            el[i].addEventListener('change', function(e) {
                var genres = localStorage.getItem('genres')
                var genresNew = []
                if (genres == null) {
                    if (this.checked) {
                        localStorage.setItem('genres', this.value)
                        getFilteredGenres()
                    }
                } else {
                    var genresBefore = genres.split(',')
                    if (this.checked) {
                        for (let i = 0; i < genresBefore.length; i++) {
                            genresNew.push(parseInt(genresBefore[i]))
                        }
                        genresNew.push(parseInt(this.value))
                        const distinct = (value, index, self) => {
                            return self.indexOf(value) === index;
                        }
                        genresNew = genresNew.filter(distinct)
                        localStorage.setItem('genres', genresNew)
                        getFilteredGenres()
                    } else {
                        var genreToRemove = parseInt(this.value)
                        for (let i = 0; i < genresBefore.length; i++) {
                            genresNew.push(parseInt(genresBefore[i]))
                        }

                        function removeValue(value, index, arr) {
                            if (value === genreToRemove) {
                                arr.splice(index, 1);
                                return true;
                            }
                            return false;
                        }
                        genresNew.filter(removeValue);
                        localStorage.setItem('genres', genresNew)
                        getFilteredGenres()
                    }

                }
            })
        }
    }
}
//zanrovi filter KRAJ


//autori filter POCETAK
{
    function oznaciAutore(){
        var authorsToCheckLs = localStorage.getItem('authors')
        var authorsToCheck = []
        var allAuthors = document.getElementsByClassName('author')
        if(authorsToCheckLs!=null){
            authorsToCheckLs = localStorage.getItem('authors').split(',')
            for (let i = 0; i < authorsToCheckLs.length; i++) {
                // ako se buni dodaj parse int
                authorsToCheck.push(authorsToCheckLs[i])
            }

            for (let i = 0; i < allAuthors.length; i++) {
                if (authorsToCheck.includes(allAuthors[i].value)) {
                    allAuthors[i].checked=true
                }
            }
        }
        else{
            for (let i = 0; i < allAuthors.length; i++) {
                allAuthors[i].checked=false

            }
        }

    }

    function aktivirajAutore() {
        var el = document.getElementsByClassName('author')
        for (let i = 0; i < el.length; i++) {
            el[i].addEventListener('change', function(e) {
                var authors = localStorage.getItem('authors')
                var authorsNew = []
                if (authors == null) {
                    if (this.checked) {
                        localStorage.setItem('authors', this.value)
                        getFilteredAuthors()
                    }
                } else {
                    var authorsBefore = authors.split(',')
                    if (this.checked) {
                        for (let i = 0; i < authorsBefore.length; i++) {
                            authorsNew.push(parseInt(authorsBefore[i]))
                        }
                        authorsNew.push(parseInt(this.value))
                        const distinct = (value, index, self) => {
                            return self.indexOf(value) === index;
                        }
                        authorsNew = authorsNew.filter(distinct)
                        localStorage.setItem('authors', authorsNew)
                        getFilteredAuthors()
                    } else {
                        var authorToRemove = parseInt(this.value)
                        for (let i = 0; i < authorsBefore.length; i++) {
                            authorsNew.push(parseInt(authorsBefore[i]))
                        }

                        function removeValue(value, index, arr) {
                            if (value === authorToRemove) {
                                arr.splice(index, 1);
                                return true;
                            }
                            return false;
                        }
                        authorsNew.filter(removeValue);
                        localStorage.setItem('authors', authorsNew)
                        getFilteredAuthors()
                    }

                }
            })
        }
    }
}
//autori filter KRAJ

//sort aktivacija POCETAK
{
    function oznaciSort(){
        var sortByLs=localStorage.getItem('sortBy')
        if(sortByLs!=null){
            document.getElementById('sortiranje').value=sortByLs;
        }
        else{
            document.getElementById('sortiranje').value=0;
        }
    }

    function sacuvajSort(){
        if(this.value!=0){
            localStorage.setItem('sortBy',this.value)
            ucitajAjax($titlesLink,titles)
        }
        else{
            localStorage.removeItem('sortBy')
            ucitajAjax($titlesLink,titles)
        }
    }
}
//sort aktivacija KRAJ

