<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ViewOnlyPagesController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//poruke(poslat kontakt, zavrsena porudzbina, admin rad sa formama...) - ViewOnlyPages
Route::get('/messagePage/{msgType}/{infoForBlank?}',[ViewOnlyPagesController::class,'messagePages'])
    ->middleware('doYouHaveAMessageForMe')->name('msgPage');

//home - ViewOnlyPages
Route::get('/',[ViewOnlyPagesController::class,'home'])->name('home');

//products - Product
Route::get('/products',[ProductController::class,'products'])->name('products');
Route::get('/products/{id}',[ProductController::class,'product'])->middleware('doesItExist')->name('product');
Route::post('/addToCart',[CartController::class,'addToCart'])->middleware('areYouLoggedIn')->name('addToCart');

//info za ajax
Route::get('/titles',[ProductController::class,'titlesAjax'])->name('titlesAjax');
Route::get('/authors4title',[ProductController::class,'authors4titleAjax'])->name('authors4titleAjax');
Route::get('/genres4title',[ProductController::class,'genres4titleAjax'])->name('genres4titleAjax');
Route::get('/authors',[ProductController::class,'authorsAjax'])->name('authorsAjax');
Route::get('/genres',[ProductController::class,'genresAjax'])->name('genresAjax');

//contact - Contact
Route::get('/contact',[ContactController::class,'contact'])->name('contact');
Route::post('/contact/send',[ContactController::class,'sendMessage'])->name('send');

//cart - Cart
Route::get('/cart',[CartController::class,'cart'])->middleware('areYouLoggedIn')->name('cart');
Route::get('/cart/checkOut',[CartController::class,'checkOut'])->name('checkOut');
Route::post('/cart/checkOut/go',[CartController::class,'checkOutGo'])->name('checkOutGo');
Route::post('/cart/plus',[CartController::class,'plus'])->name('addQ');
Route::post('/cart/minus',[CartController::class,'minus'])->name('removeQ');
Route::post('/cart/delete',[CartController::class,'delete'])->name('removeProd');

//author - ViewOnlyPages
Route::get('/author',[ViewOnlyPagesController::class,'author'])->name('author');

//user (sign up, log in) - User
Route::middleware(['blockPagesForKnownUsers'])->group(function () {

Route::get('/signUp',[UserController::class,'signUp'])->name('signUp');
Route::post('/signUpGo',[UserController::class,'signUpGo'])->name('signUpGo');
Route::get('/logIn',[UserController::class,'logIn'])->name('logIn');
Route::post('/logInGo',[UserController::class,'logInGo'])->name('logInGo');

});
Route::get('/logOut',[UserController::class,'logOutGo'])->middleware('blockPagesForUnknownUsers')->name('logOut');


//admin - Admin

Route::middleware(['areYouAdmin'])->group(function () {

//ADMIN STRANICA
Route::get('/admin/{type}/{moreInfo?}',[AdminController::class,'admin'])->name('admin');

//DODAVANJE
Route::post('/admin/addProdGo',[AdminController::class,'addProduct'])->name('addProdGo');
Route::post('/admin/addAuthor',[AdminController::class,'addAuthor'])->name('addAuthor');
Route::post('/admin/addGenre',[AdminController::class,'addGenre'])->name('addGenre');
Route::post('/admin/addAdminGo',[AdminController::class,'addAdmin'])->name('addAdminGo');

//IZMENA
Route::post('/admin/upProdGo',[AdminController::class,'upProduct'])->name('upProdGo');
Route::post('/admin/upAuthor',[AdminController::class,'upAuthor'])->name('upAuthor');
Route::post('/admin/upGenre',[AdminController::class,'upGenre'])->name('upGenre');
Route::post('/admin/upAdminGo',[AdminController::class,'upAdmin'])->name('upAdminGo');
Route::post('/admin/upAdminPasswordGo',[AdminController::class,'upAdminPassword'])->name('upAdminPasswordGo');

//DEAKTIVIRANJE
Route::post('/admin/disableProduct',[AdminController::class,'disableProduct'])->name('disableProduct');
Route::post('/admin/disableAuthor',[AdminController::class,'disableAuthor'])->name('disableAuthor');
Route::post('/admin/disableGenre',[AdminController::class,'disableGenre'])->name('disableGenre');
Route::post('/admin/disableAdmin',[AdminController::class,'disableAdmin'])->name('disableAdmin');
Route::post('/admin/disableUser',[AdminController::class,'disableUser'])->name('disableUser');

//AKTIVIRANJE
Route::post('/admin/enableProduct',[AdminController::class,'enableProduct'])->name('enableProduct');
Route::post('/admin/enableAuthor',[AdminController::class,'enableAuthor'])->name('enableAuthor');
Route::post('/admin/enableGenre',[AdminController::class,'enableGenre'])->name('enableGenre');
Route::post('/admin/enableAdmin',[AdminController::class,'enableAdmin'])->name('enableAdmin');
Route::post('/admin/enableUser',[AdminController::class,'enableUser'])->name('enableUser');

//BRISANJE
Route::post('/admin/removeProduct',[AdminController::class,'removeProduct'])->name('removeProduct');
Route::post('/admin/removeAuthor',[AdminController::class,'removeAuthor'])->name('removeAuthor');
Route::post('/admin/removeGenre',[AdminController::class,'removeGenre'])->name('removeGenre');


//statistics json za ajax
Route::get('/visitors',[AdminController::class,'visitsAjax'])->name('visitors');
Route::get('/orders',[AdminController::class,'ordersAjax'])->name('orders');
Route::get('/titles4orders',[AdminController::class,'titles4ordersAjax'])->name('titles4orders');


//user json za ajax
Route::get('/userActivities',[AdminController::class,'userActivitiesAjax'])->name('userActivities');
Route::get('/adminActivities',[AdminController::class,'adminActivitiesAjax'])->name('adminActivities');


});
