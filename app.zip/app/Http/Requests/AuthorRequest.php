<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AuthorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'author'=>[
                'required',
                'max:200',
                'string',
                'regex:/^([A-Z,Š,Đ,Č,Ć,Ž,a-z,š,đ,ž,č,ć]{1,200}[\s,\-]{0,10}){1,10}$/'
            ]
        ];
    }

    public function messages(){
        return [
            'author.required' => 'Polje autor je obavezno.',
            "author.regex" => "Polje autor može a i ne mora da započinje velikim slovom i da bude
            dužine između 1 i 200 karaktera. Primeri pravilnih formata za unos: Dejan Tiago-Stanković,
            Olivera Milošević, ar magazin.",

        ];
    }
}
