<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductAddRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [

            "title" => [
                'required',
                'string',
                'min:1',
                'max:200',
                //'regex:/^([A-Z,Š,Đ,Č,Ć,Ž,a-z,š,đ,ž,č,ć]{1,199}[\s,\-]{0,10}){1,10}$/'
                'regex:/^[A-Z,Š,Đ,Č,Ć,Ž][A-Z,Š,Đ,Č,Ć,Ž,a-z,š,đ,ž,č,ć\d,\W,\s,\,,\.,\-]{0,198}$/'
                // 'regex:/^[A-Z,Š,Đ,Č,Ć,Ž][a-z,š,đ,ž,č,ć]{1,199}$/'
            ],
            "desc"=>[
                'required',
                'string',
                'max:2000',
                'regex:/^[\d,\w,\W]*$/'
            ],
            "formatA"=>[
                'required',
                'string',
                'max:30',
                'regex:/^[\d]{1,13}(x){1}[\d]{1,13}(\s){1}(cm){1}$/'
            ],
            "numPages"=>[
                'required',
                'numeric',
                'regex:/^[0-9]{1,5}$/'
            ],
            "letter"=>[
                'required',
                'string',
                'max:20',
                'regex:/^[A-Z,Š,Đ,Č,Ć,Ž][a-z,š,đ,ž,č,ć]{1,19}$/'
            ],
            "coverType"=>[
                'required',
                'string',
                'max:20',
                'regex:/^[A-Z,Š,Đ,Č,Ć,Ž][a-z,š,đ,ž,č,ć]{1,19}$/'
            ],
            "published"=>[
                'required',
                'date',
//                'regex:/^[0-9]{4}(\-)[0-1][0-9](\-)[0-1][0-9]$/'
            ],
            "isbn"=>[
                'required',
                'string',
                'max:100',
                'regex:/^[0-9]{3}(\-)[0-9]{2}(\-)[0-9]{3}(\-)[0-9]{4}(\-)[0-9]{1}$/'
            ],
            "translator"=>[
                'nullable',
                'max:100',
                'string',
                'regex:/^([A-Z,Š,Đ,Č,Ć,Ž][a-z,š,đ,ž,č,ć]{1,99}[\s,\-]{0,10}){1,10}$/'
            ],
            "price"=>[
                'required',
                'numeric',
                'min:1',
                'max:9999999999'
            ],
            "cover"=>[
                'required',
                'file',
                'max:2084',
                'mimes:jpg,png'
            ],
            "author"=>[
                'required',
                'array',
                'min:1',
                'max:5'
            ],
//            "pisac.*"=>[
//                'required'
//            ],
            "genre"=>[
                'required',
                'array',
                'min:1',
                'max:7'
            ],
//            "zanr.*"=>[
//                'required'
//            ]

        ];
    }

    public function messages(){
        return [
            'title.required'=>"Polje naslov je obavezno.",
            'title.string'=>"Naslov mora da bude string.",
            'title.min'=>"Minimalna dužina naslova je jedan karakter.",
            'title.max'=>"Maksimalna dužina naslova je 200 karaktera.",
            "title.regex" => "Polje :attribute mora da započinje velikim slovom i da bude dužine između 1 i 200 karaktera.",

            'desc.required'=>"Polje opis je obavezno.",
            'desc.string'=>"Opis mora da bude srting.",
            'desc.max'=>"Maksimalna dužina opisa je 2000 karaktera.",
            "desc.regex" => "Polje opis mora da bude popunjeno pravilno (bez {} []). Maksimum 2000 karaktera.",


            'formatA.required'=>'Polje format je obavezno.',
            'formatA.string'=>'Polje format mora da bude string.',
            'formatA.max'=>'Maksimum 30 karaktera za format.',
            "format.regex" => "Polje format mora da bude formata 13x21 cm. Maksimum 30 karaktera.",


            'numPages.required'=>'Polje broj stranica je obavezno.',
            'numPages.numeric'=>'Broj strana mora da bude... pa... broj.',
            "numPages.regex" => "Polje broj strana mora da bude maksimalne dužine 5 karaktera, samo cifre.",


            'letter.required'=>'Polje pismo je obavezno.',
            'letter.string'=>'Pismo mora da bude string.',
            'letter.max'=>'Maksimalna dužina za pismo je 20.',
            "letter.regex" => "Polje pismo mora da započinje velikim slovom i da bude dužine između 1 i 20 karaktera.",


            'coverType.required'=>'Polje tip korica je obavezan.',
            'coverType.string'=>'Tip korica mora da bude string.',
            'coverType.max'=>'Maksimalna dužina za tip korica je 20.',
            "coverType.regex" => "Polje tip korica mora da započinje velikim slovom i da bude dužine između 1 i 20 karaktera.",


            'published.required'=>'Polje izdato(datum) je obavezno.',
            'published.date'=>'Datum mora da bude... pa... datum.',
            'published.regex'=>'Datum mora da bude u formatu YYYY-MM-DD',

            'isbn.required'=>'Polje ISBN je obavezno.',
            'isbn.string'=>'ISBN mora da bude string.',
            'isbn.max'=>'Maksimalna dužina ISBN je 100 karaktera.',
            "isbn.regex" => "Polje ISBN mora da bude formata 978-86-521-4428-0.",


            'author.required'=>'Naslov mora da ima barem jednog autora.',
            'author.array'=>'Autor mora da bude niz.',
            'author.min'=>'Minimum autora je 1.',
            'author.max'=>'Maksimum autora je 5.',


            'genre.required'=>'Naslov mora da ima neki žanr.',
            'genre.array'=>'Žanr mora da bude niz.',
            'genre.min'=>'Minimum žanrova je 1.',
            'genre.max'=>'Maksimum žanrova je 7.',

            'translator.nullable'=>'Polje prevodilac nije obavezno.',
            'translator.max'=>'Maksimalna dužina imena prevodioca je 100 karaktera.',
            'translator.string'=>'Prevodilac mora da bude string.',
            "translator.regex" => "Polje prevodilac mora da započinje velikim slovom i da bude dužine između 1 i 100 karaktera.",

            'price.numeric'=>'Cena mora da bude broj.',
            "price.required"=>'Polje cena je obavezno.',
            "price.min"=>"Minimalna cena je 1 dinar.",
            "price.max"=>"Maksimalna cena je 9999999999 dinara.",

            "cover.mimes"=>"Format slike mora da bude ili JPG ili PNG.",
            'cover.required'=>'Polje slika je obavezno.',
            'cover.file'=>'Slika mora da bude fajl.',
            'cover.max:2084'=>'Maksimalna veličina slike je 2084',
        ];
    }
}
