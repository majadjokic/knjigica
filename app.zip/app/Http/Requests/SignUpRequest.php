<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SignUpRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'firstNameS'=>[
                'required',
                'regex:/^([A-ZĐĆČŽŠ][a-zđćčšž]{1,19}\-{0,1}){1,2}$/'
            ],
            'lastNameS'=>[
                'required',
                'regex:/^([A-ZĐĆČŽŠ][a-zđćčšž]{1,19}\-{0,1}){1,2}$/'
            ],
            'userNameS'=>[
                'required',
                'regex:/^([\d\_ a-z A-Z]*){1,30}$/'
            ],
            'userMailS'=>[
                'required',
                'regex:/^[a-z A-Z][\-\_\.\!\d a-z A-Z]*\@[a-z]{2,10}(\.[a-z]{2,3}){1,2}$/'
            ],
            'userPassS'=>[
                'required',
                'min:8',
                'max:50',
                'regex:/^[\d,\w,\W]*$/'
            ],
            'userPassConfS'=>[
                'required',
                'min:8',
                'max:50'
            ]
        ];
    }

    public function messages(){
        return [
            "firstNameS.required"=>"Polje ime je obavezno.",
            "lastNameS.required"=>"Polje prezime je obavezno.",
            'userNameS.required'=>"Polje username je obavezno.",
            "userMailS.required"=>"Polje email je obavezno.",
            "userPassS.required"=>"Polje lozinka je obavezno.",
            "userPassConfS.required"=>"Polje potvrde lozinke je obavezno.",


            "firstNameS.regex"=>"Ime mora da počinje velikim slovom i da bude dužine od 20 slova.
            Ako imate dva imena pišite ih u formatu Ana-Maria.",
            "lastNameS.regex"=>"Prezime mora da počinje velikim slovom i da bude dužine od 20 slova.
            Ako imate dva prezimena pišite ih u formatu Anić-Marijić.",
            'userNameS.regex'=>'Username nesme biti duži od 30 karaktera. Dozvoljeni karakteri
            za username su velika i mala slova, brojevi i donja crta.',
            "userMailS.regex" => "Polje email mora da bude po formatu maja@gmail.com",
            "userPassS.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "userPassS.max"=>"Maksimalna dužina lozinke je 50 karaktera.",
            "userPassConfS.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "userPassConfS.max"=>"Maksimalna dužina lozinke je 50 karaktera."

        ];
    }
}
