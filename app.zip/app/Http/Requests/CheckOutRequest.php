<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CheckOutRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'paymentMethod'=>[
                'required'
            ],
            'card'=>[
                'nullable',
                'max:19',
                'regex:/^([0-9]{4}\-){3}[0-9]{4}$/'
            ],
            'country'=>[
                'required',
                'doesnt_start_with:0'
            ],
            'city'=>[
                'required',
                'max:30',
                'regex:/^[A-ZĐĆČŽŠ][\s\d\' a-zđćčšž A-ZĐĆČŽŠ]*$/'
            ],
            'address'=>[
                'required',
                'max:200',
                'regex:/^[\s\d\'\,\.\- a-zđćčšž A-ZĐĆČŽŠ]*$/'
            ]
        ];
    }

    public function messages()
    {
        return [
            'paymentMethod.required'=>"Izaberite način plaćanja.",
            'city.required'=>"Polje grad je obavezno.",
            'country.required'=>"Polje država je obavezno.",
            'country.doesnt_start_with'=>"Morate da izaberete državu.",
            'address.required'=>"Polje adresa je obavezno.",
            'card.regex'=>"Polje kartica treba da bude formata 0000-0000-0000-0000",
            'city.regex'=>"Pogrešno ste uneli grad. Mora da bude veliko početno slovo.",
            'city.max'=>"Ime grada nesme biti duže od 30 karaktera.",
            'address.regex'=>"Pogrešno ste uneli adresu. Molimo Vas unesite nešto normalno.",
            'address.max'=>"Adresa nesme biti duža od 200 karaktera."
        ];
    }
}
