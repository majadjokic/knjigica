<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdminUpdatePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {

        return [
            'passwordOld'=>[
                'required',
                'min:8',
                'max:50',
                'regex:/^[\d,\w,\W]*$/'
            ],
            'password'=>[
                'required',
                'min:8',
                'max:50',
                'regex:/^[\d,\w,\W]*$/'
            ],
            'passwordConf'=>[
                'required',
                'min:8',
                'max:50'
            ]
        ];
    }

    public function messages(){
        return [
            "passwordOld.required"=>"Polje lozinka je obavezno.",
            "password.required"=>"Polje lozinka je obavezno.",
            "passwordConf.required"=>"Polje potvrde lozinke je obavezno.",

            "passwordOld.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "passwordOld.max"=>"Maksimalna dužina lozinke je 50 karaktera.",
            "password.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "password.max"=>"Maksimalna dužina lozinke je 50 karaktera.",
            "passwordConf.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "passwordConf.max"=>"Maksimalna dužina lozinke je 50 karaktera."

        ];
    }
}
