<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdminAddRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {

        return [
            'firstName'=>[
                'required',
                'regex:/^([A-ZĐĆČŽŠ][a-zđćčšž]{1,19}\-{0,1}){1,2}$/'
            ],
            'lastName'=>[
                'required',
                'regex:/^([A-ZĐĆČŽŠ][a-zđćčšž]{1,19}\-{0,1}){1,2}$/'
            ],
            'username'=>[
                'required',
                'regex:/^([\d\_ a-z A-Z]*){1,30}$/'
            ],
            'email'=>[
                'required',
                'regex:/^[a-z A-Z][\-\_\.\!\d a-z A-Z]*\@[a-z]{2,10}(\.[a-z]{2,3}){1,2}$/'
            ],
            'password'=>[
                'required',
                'min:8',
                'max:50',
                'regex:/^[\d,\w,\W]*$/'
            ],
            'passwordConf'=>[
                'required',
                'min:8',
                'max:50'
            ]
        ];
    }

    public function messages(){
        return [
            "firstName.required"=>"Polje ime je obavezno.",
            "lastName.required"=>"Polje prezime je obavezno.",
            'username.required'=>"Polje username je obavezno.",
            "email.required"=>"Polje email je obavezno.",
            "password.required"=>"Polje lozinka je obavezno.",
            "passwordConf.required"=>"Polje potvrde lozinke je obavezno.",


            "firstName.regex"=>"Ime mora da počinje velikim slovom i da bude dužine od 20 slova.
            Ako imate dva imena pišite ih u formatu Ana-Maria.",
            "lastName.regex"=>"Prezime mora da počinje velikim slovom i da bude dužine od 20 slova.
            Ako imate dva prezimena pišite ih u formatu Anić-Marijić.",
            'username.regex'=>'Username nesme biti duži od 30 karaktera. Dozvoljeni karakteri
            za username su velika i mala slova, brojevi i donja crta.',
            "email.regex" => "Polje email mora da bude po formatu maja@gmail.com",
            "password.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "password.max"=>"Maksimalna dužina lozinke je 50 karaktera.",
            "passwordConf.min"=>"Minimalna dužina lozinke je 8 karaktera.",
            "passwordConf.max"=>"Maksimalna dužina lozinke je 50 karaktera."

        ];
    }
}
