<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AreYouLoggedIn
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if(!session()->has('user')){
            $redFrom=$request->route()?->getName();
            session()->put('redFrom',$redFrom);
            if($redFrom=='cart'){
                session()->put('lastPage','cart');
            }
            else if($redFrom=='addToCart'){
                session()->put('lastPage','product');
            }
            return redirect()->route('logIn');
        }
        return $next($request);
    }
}
