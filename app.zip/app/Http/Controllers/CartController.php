<?php

namespace App\Http\Controllers;

use App\Http\Requests\CheckOutRequest;
use App\Models\Carts;
use App\Models\Counties;
use App\Models\Orders;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Psy\Util\Json;

class CartController extends Controller
{
    public $data;

    public function cart(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        session()->put('lastPage','cart');
        $ucObj=new Carts();
        $user=intval(session()->get('userId'));
        $uc=$ucObj->usersCart($user);
        $this->data['cart']=$uc;
        //priceOfCart($uc);
        if($uc!='none'){

            $idCart=0;
            foreach($uc as $u){
                $idCart=$u->cart_id;
            }
            $this->data['total']=$ucObj->sumPriceCart($idCart);
            $this->data['cartId']=$idCart;
        }
        return view('cart.cart',$this->data);
    }


    public function addToCart(Request $request){
        $article=$request->atcId;
        $price=$request->atcPrice;
        $quantity=$request->atcQuantity;
        $artInt=intval($article);
        $ucObj2=new Carts();
        $user=intval(session()->get('userId'));
        $uc2=$ucObj2->usersCart($user);
        $idCart=0;
        $prodInCart=[];
        try{
            \DB::beginTransaction();
            if($uc2=='none'){
                $idCart=\DB::table('carts')->insertGetId([
                    "user_id"=>$user,
                    "cart_date"=>date('d.m.Y.'),
                    "cart_timestamp"=>strtotime(date('d.m.Y.')),
                    "is_checked_out"=>0
                ]);
                \DB::table('cart_lists')->insert([
                    "cart_id"=>$idCart,
                    "prod_id"=>$article,
                    "prod_price"=>$price,
                    "num_of_prod"=>$quantity
                ]);
                $message = "Dodato " . $quantity . " komada proizvoda u korpu. Trenutno imate " . $quantity . " komada ovog proizvoda u korpi.";
                session()->put('messageAddedProd',$message);
                session()->put('msgap4',$artInt);
            }
            else{
                foreach($uc2 as $u){
                    $idCart=$u->cart_id;
                    array_push($prodInCart,$u->prod_id);
                }
                if(in_array($artInt,$prodInCart)){
                    $ucObj2->addProdQuan($idCart,$article,$quantity);
                }
                else{
                    \DB::table('cart_lists')->insert([
                        "cart_id"=>$idCart,
                        "prod_id"=>$article,
                        "prod_price"=>$price,
                        "num_of_prod"=>$quantity
                    ]);
                    $message = "Dodato " . $quantity . " komada proizvoda u korpu. Trenutno imate " . $quantity . " komada ovog proizvoda u korpi.";
                    session()->put('messageAddedProd',$message);
                    session()->put('msgap4',$artInt);
                }
                //session()->put('mmmmm',$idCart);
                //return redirect('logIn');


            }
            \DB::commit();
            return redirect()->route('product',['id'=>$artInt]);
        }
        catch(\Exception $ex){
            \DB::rollback();
            return $ex->getMessage();
        }
    }

    public function plus(Request $request){
        $article=$request->plusProd;
        $cart=$request->plusCart;
        $quantity=$request->plusNum;
        $artInt=intval($article);
        //$idCart=0;
        $ucObj=new Carts();
        $user=intval(session()->get('userId'));
        $uc=$ucObj->usersCart($user);

        $ucObj->addProdQuan($cart,$article,$quantity);
        return redirect()->route('cart');
    }

    public function minus(Request $request){
        $article=$request->minusProd;
        $cart=$request->minusCart;
        $quantity=$request->minusNum;
        $artInt=intval($article);
        //$idCart=0;
        $ucObj=new Carts();
        $user=intval(session()->get('userId'));
        $uc=$ucObj->usersCart($user);

        $ucObj->removeProdQuan($cart,$article,$quantity);
        return redirect()->route('cart');
    }

    public function delete(Request $request){
        $article=$request->removeProd;
        $cart=$request->removeCart;
        $ucObj=new Carts();
        $ucObj->removeProd($cart,$article);
        $ucObj->countItems($cart);
        return redirect()->route('cart');
    }

    public function checkOut(Request $request){
        $cartId=$request->cartId;
        $ucObj=new Carts();
        $conObj=new Counties();

        $this->data['cartPrice']=$ucObj->sumPriceCart($cartId);
            $this->data['cartList']=$ucObj->cartToCheckOut($cartId);
            $this->data['countries']=$conObj->allCountries();
            $this->data['cartId']=$cartId;
            return view('cart.checkOut',$this->data);



    }

    public function checkOutGo(CheckOutRequest $request){


        $cartId=$request->cartId;
        $payMet=$request->paymentMethod;
        $card=$request->card;
        $country=$request->country;
        $city=$request->city;
        $address=$request->address;
        $ucObj=new Carts();
        $total=$ucObj->sumPriceCart($cartId);
        $errors=0;
        if($payMet=='kartica'&&$card==''){
            session()->put('cardWrong','Ako ste izabrali karticu kao metod placanja onda morate da popunite polje kartica');
            $errors++;
        }
        else if($payMet=='kartica'&&$card!=''){
            session()->forget('cardWrong');
        }
        if($errors!=0){
            return redirect()->back();
        }
        else{
            try{
                \DB::beginTransaction();
                session()->put('messageForDisplay',"true");
                $idPay=DB::table('payments')->insertGetId([
                    "cart_id"=>$cartId,
                    "price"=>$total,
                    "payment_method"=>$payMet,
                    "card"=>$card
                ]);
                DB::table('orders')->insert([
                    "cart_id"=>$cartId,
                    "address"=>$address,
                    "city"=>$city,
                    "country_id"=>$country,
                    "payment_id"=>$idPay
                ]);
                DB::table('carts')->where('id','=',$cartId)
                    ->update(['is_checked_out'=>1]);


                session()->forget('messageAddedProd');
                session()->forget('msgap4');

                $user_name=session()->get('user');
                $type_user=session()->get('role');
                if($type_user==1){
                    $type_user='admin';
                }
                else if($type_user==2){
                    $type_user='known';
                }
                $activity="Korisnik ".$user_name." je obavio kupovinu.";
                $date=date('d.m.Y.');
                $time=date('H:i:s');
                DB::table('activities')
                    ->insert([
                        'type_user'=>$type_user,
                        'user_name'=>$user_name,
                        'activity'=>$activity,
                        'date'=>$date,
                        'time'=>$time]);

                \DB::commit();
            }
            catch (\Exception $ex){
                DB::rollback();
                session()->forget('messageForDisplay');
                return redirect()->back()->with("error", $ex->getMessage());
            }
        }

        return redirect()->route('msgPage',['msgType'=>'orderSent']);

    }


}
