<?php

namespace App\Http\Controllers;

use App\Http\Requests\AdminAddRequest;
use App\Http\Requests\AdminUpdatePasswordRequest;
use App\Http\Requests\AdminUpdateRequest;
use App\Http\Requests\GenreRequest;
use App\Http\Requests\ProductAddRequest;
use App\Http\Requests\ProductUpdateRequest;
use App\Http\Requests\AuthorRequest;
use App\Models\ContactEmails;
use App\Models\Users;
use App\Models\Activities;
use App\Models\Authors;
use App\Models\Genres;
use App\Models\Orders;
use App\Models\Titles;
use App\Models\Visitors;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Psy\Util\Json;

class AdminController extends Controller
{
    public $data;

    public function admin($type,$moreInfo=0){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');
        $aObj=new Authors();
        $tObj=new Titles();
        $gObj=new Genres();
        $ordObj=new Orders();
        $eObj=new ContactEmails();
        $uObj=new Users();

        //statistika
        if($type=="statistics"){
            session()->put('typeAdmin','statistics');


            $t3=$ordObj->top3Products();
            $t=$ordObj->topProducts();

            //za ovu celinu se koriste i json f-je visitsAjax(),ordersAjax()
            $this->data['top3']=$t3;
            $this->data['topProd']=$t;

            return view('admin.statistics', $this->data);

        }

        //prizvodi
        else if ($type=='products'){
            session()->put('typeAdmin','products');

            //proizvodi koji su u prodaji
            $tS=$tObj->allTitlesForSale();
            $this->data['titlesForSale']=$tS;

            //proizvodi koji nisu u prodaji
            $tNS=$tObj->allTitlesNotForSale();
            $this->data['titlesNotForSale']=$tNS;


            return view('admin.products', $this->data);
        }
        else if($type=='addProd'){
            //dodavanje proizvoda
            $a=$aObj->activeAuthors();
            $g=$gObj->activeGenres();
            $this->data["genres"]=$g;
            $this->data["authors"]=$a;
            //pozvati view za dodaju proizvoda
            return view('admin.addProduct',$this->data);
        }
        else if($type=='upProd'){
            //izmena proizvoda
            $title=intval($moreInfo);
            $t=$tObj->oneTitle($title);
            $tg=$tObj->genresForTitle($title);
            $ta=$tObj->authorsForTitle($title);
            $a=$aObj->activeAuthors();
            $g=$gObj->activeGenres();
            $g4t=[];
            $a4t=[];
            foreach($tg as $tgg){
                array_push($g4t,$tgg->genre_id);
            }

            foreach($ta as $taa){
                array_push($a4t,$taa->author_id);
            }

            session()->put('g4t',$g4t);
            session()->put('a4t',$a4t);

            $this->data["title2update"]=$t;
            $this->data["genres"]=$g;
            $this->data["authors"]=$a;
            //pozvati view za izmenu proizvoda
            return view('admin.updateProduct',$this->data);
        }
        else if($type=='disProd'){
            $title=intval($moreInfo);
            $tt=$tObj->oneTitle($title);

            foreach($tt as $t){
                $ovoIme=$t->title;
                $ovoId=$t->id;
            }
            $this->data['toDisName']=$ovoIme;
            $this->data['toDisId']=$ovoId;
            $this->data['whereToDis']='titles';
            $this->data['whereYes']='disableProduct';
            $this->data['whereNo']='products';
            return view('admin.disable',$this->data);
        }
        else if($type=='enProd'){
            $title=intval($moreInfo);
            $tt=$tObj->oneTitle($title);

            foreach($tt as $t){
                $ovoIme=$t->title;
                $ovoId=$t->id;
            }
            $this->data['toEnName']=$ovoIme;
            $this->data['toEnId']=$ovoId;
            $this->data['whereToEn']='titles';
            $this->data['whereYes']='enableProduct';
            $this->data['whereNo']='products';
            return view('admin.enable',$this->data);
        }
        else if($type=='delProd'){
            $title=intval($moreInfo);
            $tt=$tObj->oneTitle($title);

            foreach($tt as $t){
                $ovoIme=$t->title;
                $ovoId=$t->id;
            }
            $this->data['toRemName']=$ovoIme;
            $this->data['toRemId']=$ovoId;
            $this->data['whereToRem']='titles';
            $this->data['whereYes']='removeProduct';
            $this->data['whereNo']='products';
            return view('admin.delete',$this->data);
        }

        //autori
        else if($type=='authors'){
            $a=$aObj->allAuthors();
            $aa=$aObj->activeAuthors();
            $an=$aObj->inactiveAuthors();

            $this->data['allAuthors']=$a;
            $this->data['activeAuthors']=$aa;
            $this->data['inactiveAuthors']=$an;
            session()->put('typeAdmin','authors');
            return view('admin.authors',$this->data);
        }
        else if($type=='disAuth'){
            $author=intval($moreInfo);
            $aa=DB::table('authors')->where('id','=',$author)->get();

            foreach($aa as $a){
                $ovoIme=$a->author;
                $ovoId=$a->id;
            }
            $this->data['toDisName']=$ovoIme;
            $this->data['toDisId']=$ovoId;
            $this->data['whereToDis']='authors';
            $this->data['whereYes']='disableAuthor';
            $this->data['whereNo']='authors';
            return view('admin.disable',$this->data);
        }
        else if($type=='enAuth'){
            $author=intval($moreInfo);
            $aa=$aObj->oneAuthor($author);

            foreach($aa as $a){
                $ovoIme=$a->author;
                $ovoId=$a->id;
            }
            $this->data['toEnName']=$ovoIme;
            $this->data['toEnId']=$ovoId;
            $this->data['whereToEn']='authors';
            $this->data['whereYes']='enableAuthor';
            $this->data['whereNo']='authors';
            return view('admin.enable',$this->data);
        }
        else if($type=='delAuth'){
            $author=intval($moreInfo);
            $aa=$aObj->oneAuthor($author);

            foreach($aa as $a){
                $ovoIme=$a->author;
                $ovoId=$a->id;
            }
            $this->data['toRemName']=$ovoIme;
            $this->data['toRemId']=$ovoId;
            $this->data['whereToRem']='authors';
            $this->data['whereYes']='removeAuthor';
            $this->data['whereNo']='authors';
            return view('admin.delete',$this->data);
        }

        //žanrovi
        else if($type=='genres'){
            $g=$gObj->allGenres();
            $ag=$gObj->activeGenres();
            $gn=$gObj->inactiveGenres();

            $this->data['allGenres']=$g;
            $this->data['activeGenres']=$ag;
            $this->data['inactiveGenres']=$gn;
            session()->put('typeAdmin','genres');
            return view('admin.genres', $this->data);
        }
        else if($type=='disGen'){
            $genre=intval($moreInfo);
            $gg=DB::table('genres')->where('id','=',$genre)->get();

            foreach($gg as $g){
                $ovoIme=$g->genre;
                $ovoId=$g->id;
            }
            $this->data['toDisName']=$ovoIme;
            $this->data['toDisId']=$ovoId;
            $this->data['whereToDis']='genres';
            $this->data['whereYes']='disableGenre';
            $this->data['whereNo']='genres';
            return view('admin.disable',$this->data);
        }
        else if($type=='enGen'){
            $genre=intval($moreInfo);

            $gg=$gObj->oneGenre($genre);

            foreach($gg as $g){
                $ovoIme=$g->genre;
                $ovoId=$g->id;
            }
            $this->data['toEnName']=$ovoIme;
            $this->data['toEnId']=$ovoId;
            $this->data['whereToEn']='genres';
            $this->data['whereYes']='enableGenre';
            $this->data['whereNo']='genres';
            return view('admin.enable',$this->data);
        }
        else if($type=='delGen'){
            $genre=intval($moreInfo);
            $gg=$gObj->oneGenre($genre);

            foreach($gg as $g){
                $ovoIme=$g->genre;
                $ovoId=$g->id;
            }
            $this->data['toRemName']=$ovoIme;
            $this->data['toRemId']=$ovoId;
            $this->data['whereToRem']='genres';
            $this->data['whereYes']='removeGenre';
            $this->data['whereNo']='genres';
            return view('admin.delete',$this->data);
        }

        //korisnici
        else if($type=='users'){
            session()->put('typeAdmin','users');
            $uu=$uObj->users();
            $ua=$uObj->admins();
            $this->data['users']=$uu;
            $this->data['admins']=$ua;
            return view('admin.users',$this->data);
        }
        else if($type=='addAdmin'){
            return view('admin.addAdmin');
        }
        else if($type=='upAdmin'){
            $upAdm=intval($moreInfo);
            $upAdmQB=$uObj->getUser($upAdm);
            $this->data['upAdmin']=$upAdmQB;
            return view('admin.updateAdmin',$this->data);
        }
        else if($type=='disAdmin'){
            $admin=intval($moreInfo);
            $adm=DB::table('users')->where('id','=',$admin)->get();

            foreach($adm as $a){
                $ovoIme=$a->username;
                $ovoId=$a->id;
            }
            $this->data['toDisName']=$ovoIme;
            $this->data['toDisId']=$ovoId;
            $this->data['whereToDis']='users';
            $this->data['whereYes']='disableAdmin';
            $this->data['whereNo']='users';
            return view('admin.disable',$this->data);
        }
        else if($type=='enAdmin'){
            $admin=intval($moreInfo);
            $adm=DB::table('users')->where('id','=',$admin)->get();

            foreach($adm as $a){
                $ovoIme=$a->username;
                $ovoId=$a->id;
            }
            $this->data['toEnName']=$ovoIme;
            $this->data['toEnId']=$ovoId;
            $this->data['whereYes']='enableAdmin';
            $this->data['whereNo']='users';
            return view('admin.enable',$this->data);
        }
        else if($type=='disUser'){
            $user=intval($moreInfo);
            $us=DB::table('users')->where('id','=',$user)->get();

            foreach($us as $u){
                $ovoIme=$u->username;
                $ovoId=$u->id;
            }
            $this->data['toDisName']=$ovoIme;
            $this->data['toDisId']=$ovoId;
            $this->data['whereToDis']='users';
            $this->data['whereYes']='disableUser';
            $this->data['whereNo']='users';
            return view('admin.disable',$this->data);
        }
        else if($type=='enUser'){
            $user=intval($moreInfo);
            $us=DB::table('users')->where('id','=',$user)->get();

            foreach($us as $u){
                $ovoIme=$u->username;
                $ovoId=$u->id;
            }
            $this->data['toEnName']=$ovoIme;
            $this->data['toEnId']=$ovoId;
            $this->data['whereYes']='enableUser';
            $this->data['whereNo']='users';
            return view('admin.enable',$this->data);
        }

        //pregled mejlova
        else if($type=='email'){
            session()->put('typeAdmin','email');
            $en=$eObj->notRepliedToEmails();
            $this->data['notRepliedTo']=$en;
            return view('admin.viewEmails',$this->data);
        }

        //ako ne postoji
        else{
            return abort(404);
        }

    }

    //json za ajax

    public function visitsAjax(){
        $vObj=new Visitors();
        $v=$vObj->allVisits();
        $this->data['visits']=$v;
        return Json::encode($v);
    }

    public function ordersAjax(){
        $oObj=new Orders();
        $orders=$oObj->allOrders();
        $this->data['orders']=$orders;
        return Json::encode($orders);
    }

    public function titles4ordersAjax(){
        $oObj=new Orders();
        $orders=$oObj->titlesForAllOrders();
        $this->data['titles4orders']=$orders;
        return Json::encode($orders);
    }

    public function userActivitiesAjax(){
        $aObj=new Activities();
        $ua=$aObj->userActivities();
        $this->data['userActivities']=$ua;
        return Json::encode($ua);
    }

    public function adminActivitiesAjax(){
        $aObj=new Activities();
        $aa=$aObj->adminActivities();
        $this->data['adminActivities']=$aa;
        return Json::encode($aa);
    }



    //add funkcije

    public function addAuthor(AuthorRequest $request){
        $authorProvera=$request->author;
        $doesExist=DB::table('authors')->where('author','=',$authorProvera)->count();
        if($doesExist!=0){
            session()->put('alreadyExistsA','Ovaj autor već postoji u bazi.');
            return redirect()->route('admin',['type'=>'authors']);
        }
        try{
            \DB::beginTransaction();
            $aut=$request->author;
            DB::table('authors')->insert(['author'=>$aut]);


            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je dodao/la pisca: ".$aut.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            session()->forget('alreadyExistsA');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }

        return redirect()->route('msgPage',['msgType'=>'added','infoForBlank'=>'addedAuthor']);


    }

    public function addGenre(GenreRequest $request){
        $genreProvera=$request->genre;
        $doesExist=DB::table('genres')->where('genre','=',$genreProvera)->count();
        if($doesExist!=0){
            session()->put('alreadyExistsG','Ovaj žanr već postoji u bazi.');
            return redirect()->route('admin',['type'=>'genres']);
        }
        try{
            \DB::beginTransaction();
            $gen=$request->genre;
            DB::table('genres')->insert(['genre'=>$gen]);


            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je dodao/la žanr: ".$gen.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            session()->forget('alreadyExistsG');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }
        return redirect()->route('msgPage',['msgType'=>'added','infoForBlank'=>'addedGenre']);
    }

    public function addProduct(ProductAddRequest $request){
        $titleProvera=$request->title;
        $doesExist=DB::table('titles')->where('title','=',$titleProvera)->count();
        if($doesExist!=0){
            session()->put('alreadyExistsP','Ovaj naslov već postoji u bazi.');
            return redirect()->route('admin',['type'=>'addProd']);
        }

        try{

            DB::beginTransaction();

            $lastId=DB::table('titles')->max('id');
            $poslednjiId=$lastId +1;

            $title=$request->title;
            $desc=$request->desc;
            $format=$request->formatA;
            $numPages=$request->numPages;
            $letter=$request->letter;
            $coverType=$request->coverType;
            $published=$request->published;
            $pubExploded=explode("-",$published);
            $dan=$pubExploded[2];
            $mesec=$pubExploded[1];
            $godina=$pubExploded[0];
            $date=$dan.". ".$mesec." ".$godina.".";
            $isbn=$request->isbn;
            $translator=$request->translator;
            $price=$request->price;
            $timestamp=time();
            $coverName=$timestamp."_".$poslednjiId.'.'.$request->cover->extension();
            $request->cover->move(public_path('assets/img/proizvodi'),$coverName);

            //sliku ovde
            $titleId=DB::table('titles')->insertGetId(
                ['title'=>$title,'description'=>$desc,'format'=>$format,
                    'num_pages'=>$numPages,'letter'=>$letter, 'cover'=>$coverName,
                    'cover_type'=>$coverType,
                    'published'=>$date,'isbn'=>$isbn,'translator'=>$translator,'price'=>$price,
                    'active'=>1
                ]);


            //autori i zanrovi u posebnim for petljama

            //title_author
            foreach($request->author as $a){
                DB::table('title_author')->insert([
                    'title_id'=>$titleId,
                    'author_id'=>$a
                ]);
            }



            //title_genre
            foreach($request->genre as $g){
                DB::table('title_genre')->insert([
                    'title_id'=>$titleId,
                    'genre_id'=>$g
                ]);
            }


            //dodavanje u aktivnosti admina
            $prod=$title;
            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je dodao/la proizvod: ".$prod.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            session()->forget('alreadyExistsP');
            DB::commit();
        }
        catch(\Exception $ex){
            if(File::exists(public_path('/assets/img/proizvodi/'.$coverName))){
                File::delete(public_path('/assets/img/proizvodi/'.$coverName));
            }
            session()->forget('messageForDisplay');
            DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }
        return redirect()->route('msgPage',['msgType'=>'added','infoForBlank'=>'addedTitle']);


    }

    public function addAdmin(AdminAddRequest $request){
        $firstName=$request->firstName;
        $lastName=$request->lastName;
        $username=$request->username;
        $email=$request->email;
        $password=$request->password;
        $passwordConf=$request->passwordConf;

        $uObj=new Users();
        $usernameExists=$uObj->doesUsernameExist($username);
        $emailExists=$uObj->doesEmailExist($email);

        $errors=0;

        if($usernameExists!=0){
            session()->put('admUsernameW','Ovaj username nije dostupan.');
            $errors++;
        }
        else{
            session()->forget('admUsernameW');
        }

        if($emailExists!=0){
            session()->put('admEmailW','Ovaj email je već postoji.');
            $errors++;
        }
        else{
            session()->forget('admEmailW');
        }

        if($passwordConf!=$password){
            session()->put('admPasswordW','Lozinke se ne podudaraju.');
            $errors++;
        }
        else{
            session()->forget('admPasswordW');
        }

        if($errors!=0){
            return redirect()->route('admin',['type'=>'users']);
        }
        else{
            try{
                \DB::beginTransaction();

                DB::table('users')->insert([
                   'first_name'=>$firstName,
                   'last_name'=>$lastName,
                   'username'=>$username,
                   'email'=>$email,
                   'u_password'=>sha1(md5(hash('haval160,4',$password))),
                    'role_id'=>1
                ]);


                $type_user="admin";
                $user_name=session()->get('user');
                $activity=$user_name." je dodao/la admina: ".$username.".";
                $date=date('d.m.Y.');
                $time=date('H:i:s');
                DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
                session()->put('messageForDisplay','true');
                session()->forget('admUsernameW');
                session()->forget('admEmailW');
                session()->forget('admPasswordW');
                \DB::commit();
            }
            catch(\Exception $ex){
                session()->forget('messageForDisplay');
                \DB::rollBack();
                return redirect()->back()->with("error", $ex->getMessage());
            }
        }
        return redirect()->route('msgPage',['msgType'=>'added','infoForBlank'=>'addedAdmin']);
    }


    //update funkcije

    public function upProduct(ProductUpdateRequest $request){
        try{
            \DB::beginTransaction();

            $prodId=$request->prodId;
            $title=$request->title;
            $desc=$request->desc;
            $format=$request->formatA;
            $numPages=$request->numPages;
            $letter=$request->letter;
            $coverType=$request->coverType;
            $published=$request->published;
            $publishedOld=$request->publishedOld;
            if($published!=null){
                $pubExploded=explode("-",$published);
                $dan=$pubExploded[2];
                $mesec=$pubExploded[1];
                $godina=$pubExploded[0];
                $date=$dan.". ".$mesec." ".$godina.".";
            }
            else{
                $date=$publishedOld;
            }
            $isbn=$request->isbn;
            $translator=$request->translator;
            $price=$request->price;
            $vreme=time();
            $oldCover=$request->oldCover;
            if($request->cover!=null){

                $coverName=$vreme."_".$prodId.'.'.$request->cover->extension();
                $request->cover->move(public_path('assets/img/proizvodi'),$coverName);
            }



            if($request->cover!=null) {
                DB::table('titles')->where('id', $prodId)->update([
                    'title' => $title, 'description' => $desc,
                    'format' => $format, 'num_pages' => $numPages,
                    'letter' => $letter, 'cover_type' => $coverType,
                    'cover'=>$coverName,
                    'published' => $date, 'isbn' => $isbn,
                    'translator' => $translator,
                    'price' => $price
                ]);
                if(File::exists(public_path('/assets/img/proizvodi/'.$oldCover))){
                    File::delete(public_path('/assets/img/proizvodi/'.$oldCover));
                }
            }
            else{
                DB::table('titles')->where('id', $prodId)->update([
                    'title' => $title, 'description' => $desc,
                    'format' => $format, 'num_pages' => $numPages,
                    'letter' => $letter, 'cover_type' => $coverType,
                    'published' => $date, 'isbn' => $isbn,
                    'translator' => $translator,
                    'price' => $price
                ]);
            }

            DB::table('title_genre')->where('title_id','=',$prodId)->delete();
            DB::table('title_author')->where('title_id','=',$prodId)->delete();

            //title_author
            foreach($request->author as $a){
                DB::table('title_author')->insert([
                    'title_id'=>$prodId,
                    'author_id'=>$a
                ]);
            }



            //title_genre
            foreach($request->genre as $g){
                DB::table('title_genre')->insert([
                    'title_id'=>$prodId,
                    'genre_id'=>$g
                ]);
            }


            $prod=$title;
            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je izmenio/la proizvod: ".$prod.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }
        return redirect()->route('msgPage',['msgType'=>'updated','infoForBlank'=>'updatedTitle']);
    }

    public function upAuthor(AuthorRequest $request){
        $aId=$request->authorId;
        $aInt=intval($aId);
        $author=$request->author;
        $doesExist=DB::table('authors')
            ->where('author','=',$author)
            ->whereNotIn('id', [$aInt])
            ->count();
        if($doesExist!=0){
            session()->put('alreadyExistsA','Ovaj autor već postoji u bazi.');
            return redirect()->route('admin',['type'=>'authors']);
        }

            try{
                \DB::beginTransaction();
                $aut=$request->author;
                DB::table('authors')
                    ->where('id','=',$aInt)
                    ->update([
                        'author'=>$author
                    ]);


                $type_user="admin";
                $user_name=session()->get('user');
                $activity=$user_name." je izmenio/la pisca: ".$aut.".";
                $date=date('d.m.Y.');
                $time=date('H:i:s');
                DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
                session()->put('messageForDisplay','true');
                session()->forget('alreadyExistsA');
                \DB::commit();
            }
            catch(\Exception $ex){
                session()->forget('messageForDisplay');
                \DB::rollBack();
                return redirect()->back()->with("error", $ex->getMessage());
            }



        return redirect()->route('msgPage',['msgType'=>'updated','infoForBlank'=>'updatedAuthor']);

    }

    public function upGenre(GenreRequest $request){
        $gId=$request->genreId;
        $gInt=intval($gId);
        $genre=$request->genre;
        $doesExist=DB::table('genres')
            ->where('genre','=',$genre)
            ->whereNotIn('id', [$gInt])
            ->count();
        if($doesExist!=0){
            session()->put('alreadyExistsG','Ovaj žanr već postoji u bazi.');
            return redirect()->route('admin',['type'=>'genres']);
        }

        try{
            \DB::beginTransaction();
            DB::table('genres')
                ->where('id','=',$gInt)
                ->update([
                    'genre'=>$genre
                ]);


            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je izmenio/la žanr: ".$genre.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            session()->forget('alreadyExistsG');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }



        return redirect()->route('msgPage',['msgType'=>'updated','infoForBlank'=>'updatedGenre']);

    }

    public function upAdmin(AdminUpdateRequest $request){
        $idAdminReq=$request->idToUp;
        $idAdmin=intval($idAdminReq);
        $firstName=$request->firstName;
        $lastName=$request->lastName;
        $username=$request->username;
        $email=$request->email;


        $uObj=new Users();
        $usernameExists=$uObj->doesUsernameExist($username);
        $emailExists=$uObj->doesEmailExistForSomeoneElse($email,$idAdmin);

        $errors=0;

        if($usernameExists!=0){
            session()->put('admUsernameW','Ovaj username nije dostupan.');
            $errors++;
        }
        else{
            session()->forget('admUsernameW');
        }

        if($emailExists!=0){
            session()->put('admEmailW','Ovaj email je već postoji.');
            $errors++;
        }
        else{
            session()->forget('admEmailW');
        }



        if($errors!=0){
            return redirect()->route('admin',['type'=>'upAdmin','moreInfo'=>$idAdmin]);
        }
        else{
            try{
                \DB::beginTransaction();

                DB::table('users')
                    ->where('id','=',$idAdmin)
                    ->update([
                    'first_name'=>$firstName,
                    'last_name'=>$lastName,
                    'username'=>$username,
                    'email'=>$email
                ]);


                $type_user="admin";
                session()->put('user',$username);
                $user_name=$username;
                $activity=$user_name." je izmenio/la admina: ".$username.".";
                $date=date('d.m.Y.');
                $time=date('H:i:s');
                DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
                session()->put('messageForDisplay','true');
                session()->forget('admUsernameW');
                session()->forget('admEmailW');
                \DB::commit();
            }
            catch(\Exception $ex){
                session()->forget('messageForDisplay');
                \DB::rollBack();
                return redirect()->back()->with("error", $ex->getMessage());
            }
        }
        return redirect()->route('msgPage',['msgType'=>'updated','infoForBlank'=>'updatedAdmin']);
    }

    public function upAdminPassword(AdminUpdatePasswordRequest $request){
        $idAdminReq=$request->idToUp;
        $idAdmin=intval($idAdminReq);

        $username=$request->username;
        $passwordOld1=$request->passwordOld;
        $passwordOld=sha1(md5(hash('haval160,4',$passwordOld1)));
        $password=$request->password;
        $passwordConf=$request->passwordConf;

        $uObj=new Users();
        $oldPasswordQB=$uObj->getUserPassword($idAdmin);
        $oldPasswordCheck="";

        foreach($oldPasswordQB as $op){
            $oldPasswordCheck=$op->u_password;
        }


        $errors=0;



        if($passwordOld!=$oldPasswordCheck){
            session()->put('admPasswordOldW','Stara lozinka koju ste uneli se ne podudara sa onom iz baze.');
            $errors++;
        }
        if($passwordConf!=$password){
            session()->put('admPasswordW','Lozinke se ne podudaraju.');
            $errors++;
        }
        else{
            session()->forget('admPasswordW');
        }

        if($errors!=0){
            return redirect()->route('admin',['type'=>'upAdmin','moreInfo'=>$idAdmin]);
        }
        else{
            try{
                \DB::beginTransaction();

                DB::table('users')
                    ->where('id','=',$idAdmin)
                    ->update([
                    'u_password'=>sha1(md5(hash('haval160,4',$password)))
                ]);


                $type_user="admin";
                $user_name=session()->get('user');
                $activity=$user_name." je izmenio/la admina: ".$username.".";
                $date=date('d.m.Y.');
                $time=date('H:i:s');
                DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
                session()->put('messageForDisplay','true');

                session()->forget('admPasswordW');
                session()->forget('admPasswordOldW');
                \DB::commit();
            }
            catch(\Exception $ex){
                session()->forget('messageForDisplay');
                \DB::rollBack();
                return redirect()->back()->with("error", $ex->getMessage());
            }
        }
        return redirect()->route('msgPage',['msgType'=>'updated','infoForBlank'=>'updatedAdmin']);
    }


    //disable funkcije

    public function disableProduct(Request $request){
        $toDis=$request->toDis;
        $intToDis=intval($toDis);


        $ime="";
        $stvar="proizvod";
        $imeQB=DB::table('titles')->where('id','=',$intToDis)->get();

        foreach($imeQB as $iq){
            $ime=$iq->title;
        }

        DB::table('titles')->where('id','=',$intToDis)
            ->update([
                'active'=>0
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je deaktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'disabled','infoForBlank'=>'disTitle']);
    }

    public function disableAuthor(Request $request){
        $toDis=$request->toDis;
        $intToDis=intval($toDis);

        $ime="";
        $stvar="autor";
        $imeQB=DB::table('authors')->where('id','=',$intToDis)->get();

        foreach($imeQB as $iq){
            $ime=$iq->author;
        }

        $authorObj=new Authors();

        $isItConected=$authorObj->countTitlesForAuthor($intToDis);
        $toWhatConected=$authorObj->titlesForAuthor($intToDis);

        if($isItConected!=0){
            session()->put('messageForDisplay','true');
            $this->data['back']='authors';
            $this->data['thisName']=$ime;
            $this->data['titlesConnectedToThis']=$toWhatConected;
            $this->data['errorMessage']="Autor ".$ime." ne može da se sakrije jer je povezan
             sa naslovima koji su dostupni kupcima.
            Morate ili da povučete te naslove iz prodaje ili da ih obrišete iz baze
             ili da promenite informacije za te naslove da više ne pripadaju tom autoru.";
            return view('messagePages.blankError',$this->data);
        }



        DB::table('authors')->where('id','=',$intToDis)
            ->update([
                'active'=>0
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je deaktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'disabled','infoForBlank'=>'disAuthor']);
    }

    public function disableGenre(Request $request){
        $toDis=$request->toDis;
        $intToDis=intval($toDis);

        $ime="";
        $stvar="žanr";
        $imeQB=DB::table('genres')->where('id','=',$intToDis)->get();

        foreach($imeQB as $iq){
            $ime=$iq->genre;
        }

        $genreObj=new Genres();

        $isItConected=$genreObj->countTitlesForGenre($intToDis);
        $toWhatConected=$genreObj->titlesForGenre($intToDis);

        if($isItConected!=0){
            session()->put('messageForDisplay','true');
            $this->data['back']='genres';
            $this->data['thisName']=$ime;
            $this->data['titlesConnectedToThis']=$toWhatConected;
            $this->data['errorMessage']="Žanr ".$ime." ne može da se sakrije jer je povezan
             sa naslovima koji su dostupni kupcima.
            Morate ili da povučete te naslove iz prodaje ili da ih obrišete iz baze
             ili da promenite informacije za te naslove da više ne pripadaju tom žanru.";
            return view('messagePages.blankError',$this->data);
        }



        DB::table('genres')->where('id','=',$intToDis)
            ->update([
                'active'=>0
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je deaktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'disabled','infoForBlank'=>'disGenre']);
    }

    public function disableAdmin(Request $request){
        $toDis=$request->toDis;
        $intToDis=intval($toDis);

        $ime="";
        $stvar="admina";
        $imeQB=DB::table('users')->where('id','=',$intToDis)->get();

        foreach($imeQB as $iq){
            $ime=$iq->username;
        }

        $usersObj=new Users();




        DB::table('users')->where('id','=',$intToDis)
            ->update([
                'active'=>0
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je deaktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'disabled','infoForBlank'=>'disAdmin']);
    }

    public function disableUser(Request $request){
        $toDis=$request->toDis;
        $intToDis=intval($toDis);

        $ime="";
        $stvar="korisnika";
        $imeQB=DB::table('users')->where('id','=',$intToDis)->get();

        foreach($imeQB as $iq){
            $ime=$iq->username;
        }

        $usersObj=new Users();




        DB::table('users')->where('id','=',$intToDis)
            ->update([
                'active'=>0
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je deaktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'disabled','infoForBlank'=>'disUser']);
    }


    //enable funkcije

    public function enableProduct(Request $request){
        $toEn=$request->toEn;
        $intToEn=intval($toEn);

        $ime="";
        $stvar="proizvod";
        $imeQB=DB::table('titles')->where('id','=',$intToEn)->get();

        foreach($imeQB as $iq){
            $ime=$iq->title;
        }

        $titleObj=new Titles();

        $isItConectedAuth=$titleObj->countInactiveAuthorsForTitle($intToEn);
        $toWhatConectedAuth=$titleObj->inactiveAuthorsForTitle($intToEn);

        $isItConectedGen=$titleObj->countInactiveGenresForTitle($intToEn);
        $toWhatConectedGen=$titleObj->inactiveGenresForTitle($intToEn);


        if($isItConectedAuth!=0||$isItConectedGen!=0){
            session()->put('messageForDisplay','true');
            $this->data['back']='products';
            $this->data['thisName']=$ime;
            $this->data['icA']=$isItConectedAuth;
            $this->data['icG']=$isItConectedGen;
            $this->data['inAuth']=$toWhatConectedAuth;
            $this->data['inGen']=$toWhatConectedGen;
            return view('messagePages.blankError',$this->data);
        }

        DB::table('titles')->where('id','=',$intToEn)
            ->update([
                'active'=>1
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je aktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'enabled','infoForBlank'=>'enTitle']);
    }

    public function enableAuthor(Request $request){
        $toEn=$request->toEn;
        $intToEn=intval($toEn);

        $ime="";
        $stvar="autor";
        $imeQB=DB::table('authors')->where('id','=',$intToEn)->get();

        foreach($imeQB as $iq){
            $ime=$iq->author;
        }



        DB::table('authors')->where('id','=',$intToEn)
            ->update([
                'active'=>1
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je aktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'enabled','infoForBlank'=>'enAuthor']);
    }

    public function enableGenre(Request $request){
        $toEn=$request->toEn;
        $intToEn=intval($toEn);

        $ime="";
        $stvar="žanr";
        $imeQB=DB::table('genres')->where('id','=',$intToEn)->get();

        foreach($imeQB as $iq){
            $ime=$iq->genre;
        }



        DB::table('genres')->where('id','=',$intToEn)
            ->update([
                'active'=>1
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je aktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'enabled','infoForBlank'=>'enGenre']);
    }

    public function enableAdmin(Request $request){
        $toEn=$request->toEn;
        $intToEn=intval($toEn);

        $ime="";
        $stvar="admina";
        $imeQB=DB::table('users')->where('id','=',$intToEn)->get();

        foreach($imeQB as $iq){
            $ime=$iq->username;
        }

        $usersObj=new Users();




        DB::table('users')->where('id','=',$intToEn)
            ->update([
                'active'=>1
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je aktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'enabled','infoForBlank'=>'enAdmin']);
    }

    public function enableUser(Request $request){
        $toEn=$request->toEn;
        $intToEn=intval($toEn);

        $ime="";
        $stvar="korisnika";
        $imeQB=DB::table('users')->where('id','=',$intToEn)->get();

        foreach($imeQB as $iq){
            $ime=$iq->username;
        }

        $usersObj=new Users();




        DB::table('users')->where('id','=',$intToEn)
            ->update([
                'active'=>1
            ]);



        $type_user="admin";
        $user_name=session()->get('user');
        $activity=$user_name." je aktivirao/la ".$stvar.": ".$ime.".";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
        session()->put('messageForDisplay','true');
        return redirect()->route('msgPage',['msgType'=>'enabled','infoForBlank'=>'enUser']);
    }

    //delete funkcije

    public function removeProduct(Request $request){

        try{
            \DB::beginTransaction();

            $toRem=$request->toRem;
            $intToRem=intval($toRem);


            $ime="";
            $slika="";
            $stvar="proizvod";

            $autori=DB::table('title_author')->where('title_id','=',$intToRem)->get();
            $zanrovi=DB::table('title_genre')->where('title_id','=',$intToRem)->get();

            foreach ($autori as $a){
                DB::table('title_author')->where('author_id','=',$a->author_id)->delete();
            }
            foreach ($zanrovi as $z){
                DB::table('title_genre')->where('genre_id','=',$z->genre_id)->delete();
            }

            $imeQB=DB::table('titles')->where('id','=',$intToRem)->get();

            foreach($imeQB as $iq){
                $ime=$iq->title;
                $slika=$iq->cover;
            }

            DB::table('titles')->where('id','=',$intToRem)->delete();
            if(File::exists(public_path('/assets/img/proizvodi/'.$slika))){
                File::delete(public_path('/assets/img/proizvodi/'.$slika));
            }


            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je obrisao/la ".$stvar.": ".$ime.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }


        return redirect()->route('msgPage',['msgType'=>'deleted','infoForBlank'=>'delTitle']);

    }

    public function removeAuthor(Request $request){

        try{
            \DB::beginTransaction();

            $toRem=$request->toRem;
            $intToRem=intval($toRem);


            $ime="";
            $stvar="autor";

            $imeQB=DB::table('authors')->where('id','=',$intToRem)->get();

            foreach($imeQB as $iq){
                $ime=$iq->author;
            }

            $brNaslova=DB::table('title_author')->where('author_id','=',$intToRem)->count();
            $naslovi=DB::table('title_author')
                ->select('title_author.author_id','titles.title')
                ->join('titles','title_author.title_id','=','titles.id')
                ->where('title_author.author_id','=',$intToRem)->get();

            if($brNaslova!=0){
                session()->put('messageForDisplay','true');
                $this->data['titlesConnectedToThis']=$naslovi;
                $this->data['back']='authors';
                $this->data['errorMessage']="Autor ".$ime." ne može da se obriše jer je
                povezan sa naslovima koji postoje u bazi (i oni dostupni korisnicima i oni nedostupni).
                Morate da ih obrišete iz baze ili da promenite informacije za te naslove da više ne pripadaju tom autoru.";
                $this->data['thisName']=$ime;
                $this->data['titlesConnectedToThis']=$naslovi;
                return view('messagePages.blankError',$this->data);
            }



            DB::table('authors')->where('id','=',$intToRem)->delete();



            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je obrisao/la ".$stvar.": ".$ime.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }


        return redirect()->route('msgPage',['msgType'=>'deleted','infoForBlank'=>'delAuthor']);

    }

    public function removeGenre(Request $request){

        try{
            \DB::beginTransaction();

            $toRem=$request->toRem;
            $intToRem=intval($toRem);


            $ime="";
            $stvar="žanr";

            $imeQB=DB::table('genres')->where('id','=',$intToRem)->get();

            foreach($imeQB as $iq){
                $ime=$iq->genre;
            }

            $brNaslova=DB::table('title_genre')->where('genre_id','=',$intToRem)->count();
            $naslovi=DB::table('title_genre')
                ->select('title_genre.genre_id','titles.title')
                ->join('titles','title_genre.title_id','=','titles.id')
                ->where('title_genre.genre_id','=',$intToRem)->get();

            if($brNaslova!=0){
                session()->put('messageForDisplay','true');
                $this->data['titlesConnectedToThis']=$naslovi;
                $this->data['back']='genres';
                $this->data['errorMessage']="Žanr ".$ime." ne može da se obriše jer je
                povezan sa naslovima koji postoje u bazi (i oni dostupni korisnicima i oni nedostupni).
                Morate da ih obrišete iz baze ili da promenite informacije za te naslove da više ne pripadaju tom žanru.";
                $this->data['thisName']=$ime;
                $this->data['titlesConnectedToThis']=$naslovi;
                return view('messagePages.blankError',$this->data);
            }



            DB::table('genres')->where('id','=',$intToRem)->delete();



            $type_user="admin";
            $user_name=session()->get('user');
            $activity=$user_name." je obrisao/la ".$stvar.": ".$ime.".";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            session()->put('messageForDisplay','true');
            \DB::commit();
        }
        catch(\Exception $ex){
            session()->forget('messageForDisplay');
            \DB::rollBack();
            return redirect()->back()->with("error", $ex->getMessage());
        }


        return redirect()->route('msgPage',['msgType'=>'deleted','infoForBlank'=>'delGenre']);

    }


}
