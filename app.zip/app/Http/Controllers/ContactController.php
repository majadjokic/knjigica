<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest;
use App\Mail\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{

    public function contact(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        //brojanje poseta
        $page="Kontakt";
        $date=date('d.m.Y.');
        $visits4page=DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->get();
        if(count($visits4page)!=0){
            $visits=0;
            foreach($visits4page as $v4p){
                $visits=$v4p->number;
            }
            $visits+=1;
            DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->update(['number'=>$visits]);
        }
        else{
            DB::table('visitors')->insert([
                'page'=>$page,
                'number'=>1,
                'date'=>$date
            ]);
        }



        session()->put('lastPage','contact');
        return view('user.contact');
    }

    public function sendMessage(ContactRequest $request){
        try{
            DB::beginTransaction();

            $firstName=$request->firstNameC;
            $lastName=$request->lastNameC;
            $email=$request->emailC;
            $text=$request->textC;

            Mail::to('contact@knjigica.com')->send(new Contact($firstName,$lastName,$email,$text));

            DB::table('contact_email')->insert([
                'first_name'=>$firstName,'last_name'=>$lastName,
                'email'=>$email,'text_mail'=>$text,
                'date'=>date('d.m.Y.'),
                'time'=>date('H:i:s')
            ]);

            $activity="Neko nam je poslao mejl. Odgovorite mu što pre.";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert([
                'type_user'=>'unknown','user_name'=>'Neko',
                'activity'=>$activity,'date'=>$date,'time'=>$time
            ]);
            session()->put('messageForDisplay',"true");

            DB::commit();
        }
        catch(\Exception $ex){
        session()->forget('messageForDisplay');
        DB::rollBack();
        return redirect()->back()->with("error", $ex->getMessage());
        }

        return redirect()->route('msgPage', ['msgType'=>'emailSent']);

    }
}
