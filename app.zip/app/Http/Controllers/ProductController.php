<?php

namespace App\Http\Controllers;

use App\Models\Authors;
use App\Models\Genres;
use Illuminate\Http\Request;
use App\Models\Titles;
use Illuminate\Support\Facades\DB;
use Psy\Util\Json;

class ProductController extends Controller
{

    public $data;

    public function products(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        //brojanje poseta
        $page="Proizvodi";
        $date=date('d.m.Y.');
        $visits4page=DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->get();
        if(count($visits4page)!=0){
            $visits=0;
            foreach($visits4page as $v4p){
                $visits=$v4p->number;
            }
            $visits+=1;
            DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->update(['number'=>$visits]);
        }
        else{
            DB::table('visitors')->insert([
                'page'=>$page,
                'number'=>1,
                'date'=>$date
            ]);
        }

        //ovo za log in
        session()->put('lastPage','products');



        return view('products.products');
    }

    public function titlesAjax(){
        $tObj=new Titles();
        $titles=$tObj->allTitlesForSale();
        $this->data['titles']=$titles;
        return Json::encode($titles);
    }

    public function authors4titleAjax(){
        $tObj=new Titles();
        $authors=$tObj->authorsForAllTitles();
        $this->data['authors4title']=$authors;
        return Json::encode($authors);
    }

    public function genres4titleAjax(){
        $tObj=new Titles();
        $genres=$tObj->genresForAllTitles();
        $this->data['genres4title']=$genres;
        return Json::encode($genres);
    }

    public function authorsAjax(){
        $aObj=new Authors();
        $authors=$aObj->activeAuthors();
        $this->data['authors']=$authors;
        return Json::encode($authors);
    }

    public function genresAjax(){
        $gObj=new Genres();
        $genres=$gObj->activeGenres();
        $this->data['genres']=$genres;
        return Json::encode($genres);
    }

    public function product($id){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');

        //brojanje poseta

        $t=intval($id);

        $page="Proizvod ";
        $titleRes=DB::table('titles')->select('id','title')->where('id','=',$t)->get();
        $title="";
        foreach($titleRes as $tr){
            $title=$tr->title;
        }
        $page.=$title;
        $date=date('d.m.Y.');
        $visits4page=DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->get();
        if(count($visits4page)!=0){
            $visits=0;
            foreach($visits4page as $v4p){
                $visits=$v4p->number;
            }
            $visits+=1;
            DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->update(['number'=>$visits]);
        }
        else{
            DB::table('visitors')->insert([
                'page'=>$page,
                'number'=>1,
                'date'=>$date
            ]);
        }


        session()->put('lastPage','product');
        //za middleware
        session()->put('product4product',$t);
        //vezano za addProdQuan model
        if(session('msgap4')!=$t){
            session()->forget('messageAddedProd');
        }
        //podaci za trazeni proizvod

        $titleObj=new Titles();

        $genres4title=$titleObj->genresForTitle($t);
        $authors4title=$titleObj->authorsForTitle($t);
        $pGen="";
        $pAut="";
        $brGen=$titleObj->countGenresForTitle($t);
        $brAut=$titleObj->countAuthorsForTitle($t);

        foreach($genres4title as $g){
            if($brGen!=1){
                $pGen.=$g->genre.", ";
                $brGen--;
            }
            else if($brGen==1){
                $pGen.=$g->genre;
                $brGen--;
            }

        }
        foreach ($authors4title as $a){
            if($brAut!=1){
                $pAut.=$a->author.", ";
                $brAut--;
            }
            else if($brAut==1){
                $pAut.=$a->author;
                $brAut--;
            }

        }

        session()->put('individualGen',$pGen);
        session()->put('individualAut',$pAut);


        $one=$titleObj->oneTitle($t);
        $this->data['product']=$one;

        return view('products.product',$this->data);
    }
}
