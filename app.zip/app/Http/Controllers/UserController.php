<?php

namespace App\Http\Controllers;

use App\Http\Requests\LogInRequest;
use App\Http\Requests\SignUpRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{

    public function logIn(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        if(session('redFrom')=='cart'&&session()->get('lastPage')=='cart'&&!session()->has('wentToSign')){
            session()->put('logIn4Action','Morate da se prijavite kako bi ste videli Vašu korpu.');
        }
        else if(session('redFrom')=='addToCart'&&session()->get('lastPage')=='product'&&!session()->has('wentToSign')){
            session()->put('logIn4Action','Morate da se prijavite kako bi ste dodali proizvod u Vašu korpu.');
        }
        else {
            session()->forget('logIn4Action');
        }
        return view('user.logIn');
    }

    public function signUp(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        session()->put('wentToSign','true');
        return view('user.signUp');
    }

    public function signUpGo(SignUpRequest $request){
        $firstName=$request->firstNameS;
        $lastName=$request->lastNameS;
        $email=$request->userMailS;
        $username=$request->userNameS;
        $pass=$request->userPassS;
        $passConf=$request->userPassConfS;
        $emailExistsQ=DB::table('users')->where('email','=',$email)->count();
        $usernameExistsQ=DB::table('users')->where('username','=',$username)->count();
        $a=gettype($emailExistsQ);
        session()->put('proba',$a);
        if($pass!=$passConf){
            session()->put("signUpGreske",true);
            session()->put('passWrong',"Vaše šifre se ne podudaraju.");

        }
        else if($pass==$passConf){
            session()->forget("passWrong");
        }
        if($emailExistsQ!=0){
            session()->put("signUpGreske",true);
            session()->put('emailExists',"Ovaj email je već u upotrebi.");

        }
        else if($emailExistsQ==0){
            session()->forget("emailExists");
        }
        if($usernameExistsQ!=0){
            session()->put("signUpGreske",true);
            session()->put('usernameExists',"Ovaj username je već u upotrebi.");

        }
        else if($usernameExistsQ==0){
            session()->forget("usernameExists");
        }
        if($pass!=$passConf||$emailExistsQ!=0||$usernameExistsQ!=0){
            return redirect()->route('signUp');
        }
        if ($pass==$passConf&&$emailExistsQ==0&&$usernameExistsQ==0){
            session()->forget("signUpGreske");
            session()->forget("passWrong");
            session()->forget("emailExists");
            DB::table("users")->insert([
                'first_name'=>$firstName,
                'last_name'=>$lastName,
                'username'=>$username,
                'email'=>$email,
                'u_password'=>sha1(md5(hash('haval160,4',$pass))),
                'role_id'=>2
            ]);
            $type_user="unknown";
            $user_name="Novi korisnik";
            $activity=$user_name." se prijavio.";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            return redirect()->route('logIn');
        }
    }

    public function logInGoStari(LogInRequest $request){
        $userMailL=$request->userMailL;
        $userPassL=$request->userPassL;
        $log=DB::table('users')->where('email','=',$userMailL)->get();
        $provera="";
        $provera="".$log;
        if($provera=="[]"){
            session()->put('emailWrongL','Nema ovog naloga na našem sajtu.');
            return redirect()->route('logIn');
        }
        else{
            session()->forget('emailWrongL');

            foreach($log as $l){
                if($l->u_password!=sha1(md5(hash('haval160,4',$userPassL)))){
                    session()->put('passWrongL','Uneli ste pogrešnu šifru.');
                    return redirect()->route('logIn');
                }
                else{

                    session()->forget('passWrongL');
                    session()->put('user',$l->username);
                    session()->put('userId',$l->id);
                    session()->put('role',$l->role_id);
                }
            }
            $page=session()->get('lastPage');

            if(session()->get('role')==1){
                $type_user="admin";
            }
            else{
                $type_user="known";
            }
            $user_name=session()->get('user');
            $activity="Korisnik ".$user_name." se ulogovao.";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            //return redirect()->route($page);
            if($page=='product'){
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                $prod4page=session()->get('product4product');
                return redirect()->route($page,['id'=>$prod4page]);

            }
            else if(!session()->has('lastPage')){
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                return redirect()->route('home');
            }
            else{
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                return redirect()->route($page);
            }
        }
    }

    public function logInGo(LogInRequest $request){
        $errors=0;
        $userMailL=$request->userMailL;
        $userPassL=$request->userPassL;
        $doesEmailExist=DB::table('users')->where('email','=',$userMailL)->count();
        $isItActiveUser=DB::table('users')
            ->where([
                ['email','=',$userMailL],
                ['active','=',1]
            ])
            ->count();
        $userInfoQB=DB::table('users')->where('email','=',$userMailL)->get();
        $userPassword="";
        $username="";
        $userRole=0;
        $userId=0;
        foreach($userInfoQB as $info){
            $userPassword=$info->u_password;
            $username=$info->username;
            $userRole=$info->role_id;
            $userId=$info->id;
        }

        if($doesEmailExist==0){
            session()->put('emailWrongL','Nema ovog naloga na našem sajtu.');
            $errors++;
            return redirect()->route('logIn');
        }else{
            session()->forget('emailWrongL');
        }
        if($userPassword!=sha1(md5(hash('haval160,4',$userPassL)))){
            session()->put('passWrongL','Uneli ste pogrešnu šifru.');
            $errors++;
        }else{
            session()->forget('passWrongL');
        }
        if($errors!=0){
            return redirect()->route('logIn');
        }
        if($isItActiveUser==0){
            return view('viewOnly.deactivatedAccount');
        }
        if($isItActiveUser!=0&&$errors==0){
            session()->put('user',$username);
            session()->put('userId',$userId);
            session()->put('role',$userRole);

            $page=session()->get('lastPage');

            if(session()->get('role')==1){
                $type_user="admin";
            }
            else{
                $type_user="known";
            }
            $user_name=session()->get('user');
            $activity="Korisnik ".$user_name." se ulogovao.";
            $date=date('d.m.Y.');
            $time=date('H:i:s');
            DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);
            //return redirect()->route($page);
            session()->forget('emailWrongL');
            session()->forget('passWrongL');
            if($page=='product'){
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                $prod4page=session()->get('product4product');
                return redirect()->route($page,['id'=>$prod4page]);

            }
            else if(!session()->has('lastPage')){
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                return redirect()->route('home');
            }
            else{
                session()->forget('logIn4Action');
                session()->forget('wentToSign');
                return redirect()->route($page);
            }
        }
    }

    public function logOutGo(){
        if(session()->get('role')==1){
            $type_user="admin";
        }
        else{
            $type_user="known";
        }
        $user_name=session()->get('user');
        $activity="Korisnik ".$user_name." se izlogovao.";
        $date=date('d.m.Y.');
        $time=date('H:i:s');
        DB::table('activities')->insert(['type_user'=>$type_user,'user_name'=>$user_name,'activity'=>$activity,'date'=>$date,'time'=>$time]);

        session()->forget('user');
        session()->forget('userId');
        session()->forget('role');

        return redirect()->route('home');
    }
}
