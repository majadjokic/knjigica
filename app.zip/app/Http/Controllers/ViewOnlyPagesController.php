<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Orders;
use Illuminate\Support\Facades\DB;

class ViewOnlyPagesController extends Controller
{
    public $data;

    public function home(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        //brojanje poseta
        $page="Početna";
        $date=date('d.m.Y.');
        $visits4page=DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->get();
        if(count($visits4page)!=0){
            $visits=0;
            foreach($visits4page as $v4p){
                $visits=$v4p->number;
            }
            $visits+=1;
            DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->update(['number'=>$visits]);
        }
        else{
            DB::table('visitors')->insert([
                'page'=>$page,
                'number'=>1,
                'date'=>$date
            ]);
        }

        session()->put('lastPage','home');
        $oObj=new Orders();
        $top=$oObj->top3Products();
        $this->data['top']=$top;

        return view('viewOnly.home',$this->data);
    }

    public function author(){
        //nesto bitno za druge funkcije sajta
        session()->forget('messageForDisplay');
        session()->forget('messageAddedProd');
        session()->forget('msgap4');

        //brojanje poseta
        $page="Autor";
        $date=date('d.m.Y.');
        $visits4page=DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->get();
        if(count($visits4page)!=0){
            $visits=0;
            foreach($visits4page as $v4p){
                $visits=$v4p->number;
            }
            $visits+=1;
            DB::table('visitors')->where([['page','=',$page],['date','=',$date]])->update(['number'=>$visits]);
        }
        else{
            DB::table('visitors')->insert([
                'page'=>$page,
                'number'=>1,
                'date'=>$date
            ]);
        }
        session()->put('lastPage','author');
        return view('viewOnly.author');
    }

    public function messagePages($msgType, $infoForBlank=""){
        session()->forget('messageAddedProd');
        session()->forget('msgap4');


        if($msgType=='emailSent'){
            return view('messagePages.emailSent');
        }
        if($msgType=='orderSent'){
            return view('messagePages.orderSent');
        }
        if($msgType=='added'){
            $whatWasAdded="";
            $whereToGo="";
            if($infoForBlank=='addedAuthor'){
                $whatWasAdded='Autor';
                $whereToGo='authors';
            }
            if($infoForBlank=='addedGenre'){
                $whatWasAdded='Žanr';
                $whereToGo='genres';
            }
            if($infoForBlank=='addedTitle'){
                $whatWasAdded='Proizvod';
                $whereToGo='products';
            }
            if($infoForBlank=='addedAdmin'){
                $whatWasAdded='Admin';
                $whereToGo='users';
            }
            $this->data['what']=$whatWasAdded;
            $this->data['where']=$whereToGo;
            session()->put('blankType',$infoForBlank);
            return view('messagePages.blankAdded',$this->data);
        }
        if($msgType=='updated'){
            $whatWasUpdated="";
            $whereToGo="";
            if($infoForBlank=='updatedAuthor'){
                $whatWasUpdated='Autor';
                $whereToGo='authors';
            }
            if($infoForBlank=='updatedGenre'){
                $whatWasUpdated='Žanr';
                $whereToGo='genres';
            }
            if($infoForBlank=='updatedTitle'){
                $whatWasUpdated='Proizvod';
                $whereToGo='products';
            }
            if($infoForBlank=='updatedAdmin'){
                $whatWasUpdated='Admin';
                $whereToGo='users';
            }
            $this->data['what']=$whatWasUpdated;
            $this->data['where']=$whereToGo;
            session()->put('blankType',$infoForBlank);
            return view('messagePages.blankEdited',$this->data);
        }
        if($msgType=='disabled'){
            $whatWasDisabled="";
            $whereToGo="";
            if($infoForBlank=='disAuthor'){
                $whatWasDisabled='Autor';
                $whereToGo='authors';
            }
            if($infoForBlank=='disGenre'){
                $whatWasDisabled='Žanr';
                $whereToGo='genres';
            }
            if($infoForBlank=='disTitle'){
                $whatWasDisabled='Proizvod';
                $whereToGo='products';
            }
            if($infoForBlank=='disAdmin'){
                $whatWasDisabled='Admin';
                $whereToGo='users';
            }
            if($infoForBlank=='disUser'){
                $whatWasDisabled='Korisnik';
                $whereToGo='users';
            }
            $this->data['what']=$whatWasDisabled;
            $this->data['where']=$whereToGo;
            session()->put('blankType',$infoForBlank);
            return view('messagePages.blankDisabled',$this->data);
        }
        if($msgType=='enabled'){
            $whatWasEnabled="";
            $whereToGo="";
            if($infoForBlank=='enAuthor'){
                $whatWasEnabled='Autor';
                $whereToGo='authors';
            }
            if($infoForBlank=='enGenre'){
                $whatWasEnabled='Žanr';
                $whereToGo='genres';
            }
            if($infoForBlank=='enTitle'){
                $whatWasEnabled='Proizvod';
                $whereToGo='products';
            }
            if($infoForBlank=='enAdmin'){
                $whatWasEnabled='Admin';
                $whereToGo='users';
            }
            if($infoForBlank=='enUser'){
                $whatWasEnabled='Korisnik';
                $whereToGo='users';
            }
            $this->data['what']=$whatWasEnabled;
            $this->data['where']=$whereToGo;
            session()->put('blankType',$infoForBlank);
            return view('messagePages.blankEnabled',$this->data);
        }
        if($msgType=='deleted'){
            $whatWasDeleted="";
            $whereToGo="";
            if($infoForBlank=='delAuthor'){
                $whatWasDeleted='Autor';
                $whereToGo='authors';
            }
            if($infoForBlank=='delGenre'){
                $whatWasDeleted='Žanr';
                $whereToGo='genres';
            }
            if($infoForBlank=='delTitle'){
                $whatWasDeleted='Proizvod';
                $whereToGo='products';
            }
            $this->data['what']=$whatWasDeleted;
            $this->data['where']=$whereToGo;
            session()->put('blankType',$infoForBlank);
            return view('messagePages.blankDeleted',$this->data);
        }
        else{
            return abort(404);
        }

    }
}
