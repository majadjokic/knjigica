<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Authors extends Model
{
    public function allAuthors(){
        return DB::table('authors')->get();
    }

    public function activeAuthors(){
        return DB::table('authors')->where('active','=',1)->get();

    }

    public function inactiveAuthors(){
        return DB::table('authors')->where('active','=',0)->get();
    }

    public function oneAuthor($id){
        return DB::table('authors')->where('id','=',$id)->get();
    }

    public function titlesForAuthor($id){
        return DB::table('title_author')
            ->select('title_author.author_id','titles.title')
            ->join('titles','title_author.title_id','=','titles.id')
            ->where([
                ['title_author.author_id','=',$id],
                ['titles.active','=',1]
            ])->get();
    }



    public function countTitlesForAuthor($id){
        return DB::table('title_author')
            ->join('titles','title_author.title_id','=','titles.id')
            ->where([
                ['title_author.author_id','=',$id],
                ['titles.active','=',1]
            ])
            ->count();
    }

}
