<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Titles extends Model
{
    public function allTitlesForSale(){
        return DB::table('titles')->where('active','=',1)->get();
    }

    public function allTitlesNotForSale(){
        return DB::table('titles')->where('active','=',0)->get();
    }

    public function getIdsForMid(){
        $izBaze=DB::table('titles')->select('id')->where('active','=',1)->get();
        $ids=[];
        foreach($izBaze as $i){
            array_push($ids,$i->id);
        }
        return $ids;
    }

    public function oneTitle($id){
        return DB::table('titles')->where('id','=',$id)->get();
    }

    public function genresForTitle($id){
        return DB::table('title_genre')
            ->select('title_genre.genre_id','genres.genre')
            ->join('genres','title_genre.genre_id','=','genres.id')
            ->where('title_genre.title_id','=',$id)->get();
    }

    public function countGenresForTitle($id){
        return DB::table('title_genre')->where('title_id','=',$id)->count();
    }

    public function authorsForTitle($id){
        return DB::table('title_author')
            ->select('title_author.author_id','authors.author')
            ->join('authors','title_author.author_id','=','authors.id')
            ->where('title_author.title_id','=',$id)->get();
    }

    public function countAuthorsForTitle($id){
        return DB::table('title_author')->where('title_id','=',$id)->count();
    }

    public function authorsForAllTitles(){
        return DB::table('title_author')
            ->select('title_author.author_id','authors.author','title_author.title_id','titles.title')
            ->join('authors','title_author.author_id','=','authors.id')
            ->join('titles','title_author.title_id','=','titles.id')
            ->get();
    }

    public function genresForAllTitles(){
        return DB::table('title_genre')
            ->select('title_genre.genre_id','genres.genre','title_genre.title_id','titles.title')
            ->join('genres','title_genre.genre_id','=','genres.id')
            ->join('titles','title_genre.title_id','=','titles.id')
            ->get();
    }

    public function inactiveAuthorsForTitle($id){
        return DB::table('title_author')
            ->select('title_author.author_id','authors.author')
            ->join('authors','title_author.author_id','=','authors.id')
            ->where([
                ['title_author.title_id','=',$id],
                ['authors.active','=',0]
            ])->get();
    }

    public function countInactiveAuthorsForTitle($id){
        return DB::table('title_author')
            ->join('authors','title_author.author_id','=','authors.id')
            ->where([
                ['title_author.title_id','=',$id],
                ['authors.active','=',0]
            ])
            ->count();
    }

    public function inactiveGenresForTitle($id){
        return DB::table('title_genre')
            ->select('title_genre.genre_id','genres.genre')
            ->join('genres','title_genre.genre_id','=','genres.id')
            ->where([
                ['title_genre.title_id','=',$id],
                ['genres.active','=',0]
            ])->get();
    }

    public function countInactiveGenresForTitle($id){
        return DB::table('title_genre')
            ->join('genres','title_genre.genre_id','=','genres.id')
            ->where([
                ['title_genre.title_id','=',$id],
                ['genres.active','=',0]
            ])
            ->count();
    }
}
