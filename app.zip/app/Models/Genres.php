<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Genres extends Model
{
    public function allGenres(){
        return DB::table('genres')->get();
    }

    public function activeGenres(){
        return DB::table('genres')->where('active','=',1)->get();
    }

    public function inactiveGenres(){
        return DB::table('genres')->where('active','=',0)->get();
    }

    public function titlesForGenre($id){
        return DB::table('title_genre')
            ->select('title_genre.genre_id','titles.title')
            ->join('titles','title_genre.title_id','=','titles.id')
            ->where([
                ['title_genre.genre_id','=',$id],
                ['titles.active','=',1]
            ])->get();
    }

    public function countTitlesForGenre($id){
        return DB::table('title_genre')
            ->join('titles','title_genre.title_id','=','titles.id')
            ->where([
                ['title_genre.genre_id','=',$id],
                ['titles.active','=',1]
            ])
            ->count();
    }

    public function oneGenre($id){
        return DB::table('genres')->where('id','=',$id)->get();
    }
}
