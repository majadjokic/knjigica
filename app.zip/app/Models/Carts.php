<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Carts extends Model
{
    public function usersCart($user){
        $count=DB::table('carts')
            ->where([
                ['user_id','=',$user],
                ['is_checked_out','=',0]
            ])
            ->count();
        if($count!=0){
            $dateOfCart=date('d.m.Y.');
            $dc=DB::table('carts')->select('cart_date')
                ->where('user_id','=',$user)->get();
            foreach($dc as $d){
                $dateOfCart=$d->cart_date;
            }
            $validToDate=strtotime($dateOfCart. ' + 6 days');
            return DB::table('cart_lists')
                ->join('carts','carts.id','=','cart_lists.cart_id')
                ->join('titles','titles.id','=','cart_lists.prod_id')
            ->where([
                ['carts.user_id','=',$user],
                ['carts.cart_timestamp','<',$validToDate],
                ['carts.is_checked_out','=',0]
            ])
            ->get();
        }
        else{
            return "none";
        }
    }

    public function addProdQuan($cartId, $prodId, $quantity){
        $upQ=0;
        $curQ=0;
        $ci=intval($cartId);
        $pi=intval($prodId);
        $message="";
        $curQres=DB::table('cart_lists')->select('num_of_prod')
            ->where([
                ['cart_id','=',$ci],
                ['prod_id','=',$pi]
            ])
            ->get();
        foreach($curQres as $cq){
            $curQ=$cq->num_of_prod;
        }
        //return $curQ;
        $newQ=intval($curQ)+intval($quantity);
        if($newQ>10){
            $upQ=10;
            DB::table('cart_lists')
                ->where([
                    ['cart_id','=',intval($cartId)],
                    ['prod_id','=',intval($prodId)]
                ])
                ->update([
                    "num_of_prod"=>$upQ
                ]);
            $message="Ne možete imati više od 10 komada jednog proizvoda u korpi. Trenutno imate 10 komada ovog proizvoda.";
        }
        else {
            $upQ = $newQ;
            DB::table('cart_lists')
                ->where([
                    ['cart_id','=',intval($cartId)],
                    ['prod_id','=',intval($prodId)]
                ])
                ->update([
                    "num_of_prod"=>$upQ
                ]);
            $message = "Dodato " . $quantity . " komada proizvoda u korpu. Trenutno imate " . $upQ . " komada ovog proizvoda u korpi.";
        }
        session()->put('messageAddedProd',$message);
        session()->put('msgap4',$pi);
    }

    public function removeProdQuan($cartId, $prodId, $quantity){
        $upQ=0;
        $curQ=0;
        $ci=intval($cartId);
        $pi=intval($prodId);
        $message="";
        $curQres=DB::table('cart_lists')->select('num_of_prod')
            ->where([
                ['cart_id','=',$ci],
                ['prod_id','=',$pi]
            ])
            ->get();
        foreach($curQres as $cq){
            $curQ=$cq->num_of_prod;
        }
        //return $curQ;
        $newQ=intval($curQ)-intval($quantity);
        if($newQ<1){
            $upQ=1;
            DB::table('cart_lists')
                ->where([
                    ['cart_id','=',intval($cartId)],
                    ['prod_id','=',intval($prodId)]
                ])
                ->update([
                    "num_of_prod"=>$upQ
                ]);

        }
        else {
            $upQ = $newQ;
            DB::table('cart_lists')
                ->where([
                    ['cart_id','=',intval($cartId)],
                    ['prod_id','=',intval($prodId)]
                ])
                ->update([
                    "num_of_prod"=>$upQ
                ]);
        }

    }

    public function removeProd($cartId,$prodId){
        $ci=intval($cartId);
        $pi=intval($prodId);
        DB::table('cart_lists')->where([
            ['cart_id','=',$ci],
            ['prod_id','=',$pi]
        ])
            ->delete();
    }

    public function countItems($cartId){
        $numItems=DB::table('cart_lists')
            ->join('carts','carts.id','=','cart_lists.cart_id')
            ->where([
                ['carts.id','=',$cartId]
            ])
            ->count();
        if($numItems==0){
            DB::table('carts')->where('id','=',$cartId)->delete();
        }
    }

    public function sumPriceCart($cartId){
        $rez=0;
        $ci=intval($cartId);
        $total=DB::table('cart_lists')
            ->select(DB::raw('SUM(cart_lists.num_of_prod * titles.price) as total'))
            ->join('titles','titles.id','=','cart_lists.prod_id')
            ->where('cart_id','=',$ci)
            ->get();
        foreach($total as $t){
            $rez=$t->total;
        }
        return $rez;
    }

    public function cartToCheckOut($cartId){
        return DB::table('cart_lists')
            ->select('cart_lists.*','titles.title','titles.price',
                DB::raw('cart_lists.num_of_prod * titles.price as total'))
            ->join('carts','carts.id','=','cart_lists.cart_id')
            ->join('titles','titles.id','=','cart_lists.prod_id')
            ->where('cart_lists.cart_id','=',$cartId)
            ->get();
    }

    public function  checkOutThisCart($cartId,$payMet,$card,$country,$city,$address,$total){
        $payId=DB::table('payments')->insertGetId([
            "cart_id"=>$cartId,
            "price"=>$total,
            "payment_method"=>$payMet,
            "card"=>$card
        ]);
        DB::table('orders')->insert([
        "cart_id"=>$cartId,
        "address"=>$address,
        "city"=>$city,
        "country_id"=>$country,
        "payment_id"=>$payId
        ]);
        DB::table('carts')
            ->where('cart_id','=',$cartId)
            ->update([
                'is_checked_out'=>1
            ]);
    }

}
