<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ContactEmails extends Model
{
    public function notRepliedToEmails(){
        return DB::table('contact_email')->where('replied_to','=',0)->get();
    }
}
