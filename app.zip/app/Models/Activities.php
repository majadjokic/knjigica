<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Activities extends Model
{
    public function userActivities(){
        return DB::table('activities')->whereNot('type_user','=','admin')->get();
    }

    public function adminActivities(){
        return DB::table('activities')->where('type_user','=','admin')->get();
    }
}
