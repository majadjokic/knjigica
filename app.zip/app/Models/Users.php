<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Users extends Model
{
    public function users(){
        return DB::table('users')
            ->select('users.*','user_roles.role')
            ->join('user_roles','users.role_id','=','user_roles.id')
            ->where('role_id','=',2)->get();
    }

    public function admins(){
        return DB::table('users')
            ->select('users.*','user_roles.role')
            ->join('user_roles','users.role_id','=','user_roles.id')
            ->where('role_id','=',1)->get();
    }

    public function doesUsernameExist($username){
        return DB::table('users')->where('username','=',$username)->count();
    }

    public function doesEmailExist($email){
        return DB::table('users')->where('email','=',$email)->count();
    }

    public function doesEmailExistForSomeoneElse($email,$id){
        return DB::table('users')
            ->where('email','=',$email)
            ->whereNot('id','=',$id)
            ->count();
    }

    public function getUser($user){
        return DB::table('users')->where('id','=',$user)->get();
    }

    public function getUserPassword($user){
        return DB::table('users')->select('u_password')->where('id','=',$user)->get();
    }
}
