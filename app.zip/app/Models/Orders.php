<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Orders extends Model
{
    public function topProducts(){
        return DB::table('cart_lists')
            ->select(DB::raw('title,SUM(cart_lists.num_of_prod) AS soled, ROW_NUMBER() OVER(ORDER BY soled DESC) AS num_row'))
            ->join('titles','cart_lists.prod_id','=','titles.id')
            ->groupBy('titles.title','titles.cover','cart_lists.prod_id')
            ->orderBy('soled','desc')
            ->limit(100)
            ->offset(3)
            ->get();
    }

    public function top3Products(){
        return DB::table('cart_lists')
            ->select('titles.id','titles.title', 'titles.cover', DB::raw('SUM(cart_lists.num_of_prod) AS soled,ROW_NUMBER() OVER(ORDER BY soled DESC) AS num_row'))
            ->join('titles','cart_lists.prod_id','=','titles.id')
            ->groupBy('titles.id','titles.title','titles.cover','cart_lists.prod_id')
            ->orderBy('soled','desc')
            ->limit(3)
            ->get();
    }

    public function allOrders(){

        return DB::table('orders')->select('orders.id','cart_lists.cart_id','carts.cart_date',
            DB::raw("CONCAT(users.first_name,' ',users.last_name) AS 'name',
            CONCAT(address, ' ',city, ' ',country)AS 'address'"),'payments.price','is_checked_out')
            ->join('payments','orders.payment_id','=','payments.id')
            ->join('countries','orders.country_id','=','countries.id')
            ->join('carts', 'orders.cart_id','=','carts.id')
            ->join('cart_lists','carts.id','=','cart_lists.cart_id')
            ->join('users','users.id','=','carts.user_id')
//            ->groupBy('orders.id')
            ->groupBy('orders.id','cart_lists.cart_id',
                'carts.cart_date', 'name','address',
                'orders.city','countries.country',
                'payments.price','is_checked_out')
            ->having('is_checked_out','=',1)
            ->get();

    }

    public function titlesForAllOrders(){
        return DB::table('titles')
            ->select('cart_lists.cart_id','titles.title')
            ->join('cart_lists','titles.id','=','cart_lists.prod_id')
            ->join('carts','carts.id','=','cart_lists.cart_id')
            ->where('carts.is_checked_out','=',1)
            ->get();
    }
}
