<div id="footer" class="d-flex justify-content-center align-items-center p-3"><h6>&copy; Maja Đokić 195/18 2023</h6></div>
