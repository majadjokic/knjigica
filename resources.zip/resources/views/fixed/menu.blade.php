<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a href="{{route("home")}}" class="navbar-brand"><img src="{{asset('assets/img/knjigicaM2.png')}}"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav">
                @if(!request()->routeIs('admin')||!request()->routeIs('adminOg'))
                    @foreach($menu as $m)
                        @if(!Session::get('role')||Session::get('role')!=1)
                            @if($m->route!='admin')
                                <li class="nav-item @if(request()->routeIs($m->route)) active @endif"><a class="nav-link" href="{{route($m->route)}}">{{$m->name}}</a></li>
                            @endif
                        @else
                            @if($m->route!='admin')
                                <li class="nav-item @if(request()->routeIs($m->route)) active @endif"><a class="nav-link" href="{{route($m->route)}}">{{$m->name}}</a></li>
                            @endif
                            @if($m->route=='admin')
                                <li class="nav-item @if(request()->routeIs($m->route)) active @endif"><a class="nav-link linkAdminMeni rounded" target="_blank" href="{{route($m->route,['type'=>'statistics'])}}">{{$m->name}}</a></li>
                            @endif
                        @endif

                    @endforeach
                @else
                    <li><h4>Admin panel</h4></li>
                @endif
            </ul>
            <ul class="navbar-nav ms-auto">

                @if(!Session::get('user'))
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('signUp')}}">Registruj se</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('logIn')}}">Uloguj se</a>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link">&emsp;&emsp;{{Session::get('user')}}</a></li>
                    <li class="nav-item">
                        <form action="{{route('logOut')}}" method="GET" name="logOutForm">
                            <button class="nav-link btn" name="logOutBtn" id="logOutBtn">Odjavi se</button>
                        </form></li>
                @endif

            </ul>
        </div>
    </div>
</nav>







