
<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>


@if(request()->routeIs('products'))
    <script src="{{asset('assets/js/products.js')}}"></script>
@endif



