@extends('layouts.layoutAdmin')

@section('description')
    Admin- blank added
@endsection

@section('keywords')
    admin, blank added
@endsection

@section('title')
    Knjigica - Dodato
@endsection

@section('contentAdmin')
    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center flex-column">
        <h1>{{$what}} je uspešno dodat u bazu! :)</h1>
        <br/>
        <a href="{{route('admin',['type'=>$where])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>
    </div>

@endsection
