@extends('layouts.layoutAdmin')

@section('description')
    Admin- blank disabled
@endsection

@section('keywords')
    admin, blank disabled
@endsection

@section('title')
    Knjigica - Deaktivirano
@endsection

@section('contentAdmin')
    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center flex-column">
        @if($what!='Admin'&&$what!='Korisnik')
        <h1>{{$what}} je uspešno povučen sa sajta! :)</h1>
        <h2>Napomena: možete da ga povratite u bilo kom trenutku</h2>
        @else
            <h1>{{$what}} nalog je uspešno deaktiviran! :)</h1>
            <h2>Napomena: možete da ga ponovo aktivirate u bilo kom trenutku</h2>
        @endif
        <br/>
        <a href="{{route('admin',['type'=> $where])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>

    </div>

@endsection
