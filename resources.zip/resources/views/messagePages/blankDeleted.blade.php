@extends('layouts.layoutAdmin')

@section('description')
    Admin- blank deleted
@endsection

@section('keywords')
    admin, blank deleted
@endsection

@section('title')
    Knjigica - Obrisano
@endsection

@section('contentAdmin')
    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center flex-column">
        <h1>{{$what}} je uspešno obrisan! :)</h1>
        <br/>
        <a href="{{route('admin',['type'=>$where])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>
    </div>

@endsection

