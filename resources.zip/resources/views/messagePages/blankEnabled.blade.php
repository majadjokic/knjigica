@extends('layouts.layoutAdmin')

@section('description')
    Admin- blank enabled
@endsection

@section('keywords')
    admin, blank enabled
@endsection

@section('title')
    Knjigica - Aktivirano
@endsection

@section('contentAdmin')
    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center flex-column">
        @if($what!='Admin'&&$what!='Korisnik')
        <h1>{{$what}} je uspešno vraćen sa sajt! :)</h1>
        <h2>Napomena: možete da ga povučete sa sajta u bilo kom trenutku</h2>
        @else
            <h1>{{$what}} nalog je uspešno aktiviran! :)</h1>
            <h2>Napomena: možete da ga ponovo deaktivirate u bilo kom trenutku</h2>
        @endif
        <br/>
        <a href="{{route('admin',['type'=> $where])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>
    </div>

@endsection

