@extends('layouts.layoutAdmin')

@section('description')
    Admin- error
@endsection

@section('keywords')
    admin, error
@endsection

@section('title')
    Knjigica - Greška
@endsection

@section('contentAdmin')
    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center flex-column">
        @if($back!='products')
        <h2>{{$errorMessage}}</h2>
        <br/>
        <h3>Naslovi za koje je povezan:</h3>
        <ul>
            @foreach($titlesConnectedToThis as $tct)
                <li><h4>{{$tct->title}}</h4></li>
            @endforeach
        </ul>
        <br/>
        <a href="{{route('admin',['type'=>$back])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>
        @else
            <h2>Naslov {{$thisName}} ne može da se vrati u prodaju jer je povezan sa autorima/žanrovima
                koji su nedostupni kupcima.
                Morate da postavite te autore/žanrove kao dostupne da bi ste mogli da obavite ovu akciju.</h2>
            <br/>
            @if($icA!=0)
            <h3>Autori (neaktivni) za koje je povezan:</h3>
            <ul>

                @foreach($inAuth as $ia)
                    <li><h4>{{$ia->author}}</h4></li>
                @endforeach

            </ul>
            <br/>
            @endif
        @if($icG!=0)
            <h3>Žanrovi (neaktivni) za koje je povezan:</h3>
            <ul>
                @foreach($inGen as $ig)
                    <li><h4>{{$ig->genre}}</h4></li>
                @endforeach
            </ul>
            <br/>
            @endif
            <a href="{{route('admin',['type'=>$back])}}" class="bojaLink"><h3>Idi na prethodnu stranicu</h3></a>
        @endif
    </div>

@endsection
