@extends('layouts.layout')

@section('description') Knjigica, online prodavnica knjiga. Pogledajte naš izbor knjiga. @endsection
@section('keywords') prodavnica, online kupovina, knjiga, knjaige, knjizara @endsection
@section('title') Knjigica - Proizvodi @endsection

@section('content')
    <div class="d-flex flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column">
        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-12 p-3">


            <form id="sortFilter" name="sortFilter" class="mt-5" method="GET" action="#">
                <div class="mb-3">
                    <p class="font-weight-bold">Pretraži naslove</p>
                    <input type="text" id="search" name="search" class="form-control" placeholder="Pretraži" value="{{request()->search ?? ''}}">
                </div>
                <div class="d-flex flex-column">
                    <div>
                        <p class="font-weight-bold">Žanrovi</p>
                        <div class="d-flex justify-content-center flex-column align-items-start pl-4 mb-3" id="filteriZanrovi">

                        </div>
                    </div>

                    <div>
                        <p class="font-weight-bold">Autori</p>
                        <div class="d-flex justify-content-center flex-column align-items-start pl-4 mb-3" id="filteriAutori">

                        </div>
                    </div>
                    <div class="mb-3">
                        <p class="font-weight-bold">Sortiraj priozvode</p>
                        <select id="sortiranje" name="sortBy" class="form-control">
                            <option value="0">Bez sortiranja</option>
                            <option value="az">Po nazivu: A-Z</option>
                            <option value="za">Po nazivu: Z-A</option>
                            <option value="asc">Po ceni: Najniža-Najviša</option>
                            <option value="desc">Po ceni: Najviša-Najniža</option>
                        </select>
                    </div>

                    <button type="button" id="ukloni" class="mt-5 btn col-xl-6">Ukloni filtere</button>

                </div>

            </form>
        </div>
        <div  class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12 p-3 row d-flex">

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 p-3 row d-flex" id="products">

            </div>

        </div>
    </div>


    {{--    ovde se poziva js sa ajax+json--}}

@endsection
