@extends('layouts.layout')

@section('description') Knjigica, online prodavnica knjiga. Detalji knjige. @endsection
@section('keywords') prodavnica, online kupovina, knjiga, knjige, knjizara @endsection
@section('title') Knjigica - Proizvod @endsection



@section('content')
@foreach($product as $product)


    @if(session()->has('messageAddedProd'))
        <div class="container-fluid">
            <div class="alert alert-success">
                <p>{{session()->get('messageAddedProd')}}</p>
            </div>
        </div>
    @endif

        <div class="d-flex justify-content-center align-items-center flex-container" id="product">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex flex-xl-row flex-lg-row flex-md-column flex-sm-column flex-column">
                <div class="p-3 col-xl-4 col-lg-4 col-md-10 col-sm-12 col-12 row d-flex justify-content-center align-items-center" id="prodImg">
                    <img class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" src="{{asset('assets/img/proizvodi/'.$product->cover)}}" alt="{{$product->title." cover"}}">
                </div>
                <div class="p-3 col-xl-8 col-lg-8 col-md-10 col-sm-12 col-12 d-flex flex-column" id="prodDesc">
                    <h2>{{$product->title}}</h2>
                    <h3>{{session()->get('individualAut')}}</h3>
                    <h4>{{session()->get('individualGen')}}</h4>
                    <br/>
                    <h3>{{$product->price}} RSD</h3>
                    <p>{{$product->description}}</p>
                    <ul>
                        <li>Format: {{$product->format}}</li>
                        <li>Broj strana: {{$product->num_pages}}</li>
                        <li>Pismo: {{$product->letter}}</li>
                        <li>Povez: {{$product->cover_type}}</li>
                        <li>Datum izdanja: {{$product->published}}</li>
                        <li>ISBN: {{$product->isbn}}</li>
                        @if($product->translator!=null)
                            <li>Prevodilac: {{$product->translator}}</li>
                        @endif
                    </ul>
                    <br/>

{{--                    OVO JE ZA NARUDZBINEEEEEE--}}

                    <form id="dodajUkorpu" name="dodajUkorpu" action="{{route('addToCart')}}" method="POST">
                        @csrf
                        <input type="hidden" name="atcId" value={{$product->id}}>
                        <input type="hidden" name="atcPrice" value={{$product->price}}>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                            <select class="form-control" id="kolicina" name="atcQuantity">
                                <option value=1>1</option>
                                <option value=2>2</option>
                                <option value=3>3</option>
                                <option value=4>4</option>
                                <option value=5>5</option>
                                <option value=6>6</option>
                                <option value=7>7</option>
                                <option value=8>8</option>
                                <option value=9>9</option>
                                <option value=10>10</option>
                            </select>
                        </div>
                        <br/>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-6">
                            <button type="submit" class="btn bg-dark text-light">Dodaj u korpu</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
@endforeach




@endsection

