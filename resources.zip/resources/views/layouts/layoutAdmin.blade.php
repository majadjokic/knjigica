<!DOCTYPE html>
<html lang="sr">
@include('fixed.head')

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a href="{{route("home")}}" class="navbar-brand"><img src="{{asset('assets/img/knjigicaM2.png')}}"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li><h4>Admin panel</h4></li>
            </ul>
            <ul class="navbar-nav ms-auto">

                <li class="nav-item">
                        <a class="nav-link">&emsp;&emsp;{{Session::get('user')}}</a>
                </li>
                    <li class="nav-item">
                        <form action="{{route('logOut')}}" method="GET" name="logOutForm">
                            <button class="nav-link btn" name="logOutBtn" id="logOutBtn">Odjavi se</button>
                        </form>
                    </li>

            </ul>
        </div>
    </div>
</nav>


<div id="adminDeo" class="col-12 d-flex flex-xl-row flex-lg-row flex-md-column flex-sm-column flex-column">
    <div id="adminMeni" class="col-xl-2 col-lg-3 col-md-12 col-sm-12 col-12 p-5">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12
        d-flex flex-xl-column flex-lg-column flex-md-row flex-sm-row flex-row">
            <div class="col-xl-12 col-lg-12 col-md-4  col-sm-4 ">
                <a href="{{route('admin',['type'=>'statistics'])}}" class="btn @if(session()->get('typeAdmin')=='statistics')  btnAdmAktivan @else btnAdmNeaktivan @endif ">Statistika prodavnice</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
            <div  class="col-xl-12 col-lg-12 col-md-4  col-sm-4 ">
                <a href="{{route('admin',['type'=>'products'])}}" class="btn  @if(session()->get('typeAdmin')=='products')  btnAdmAktivan @else btnAdmNeaktivan @endif">Rad sa proizvodima</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
            <div class="col-xl-12 col-lg-12 col-md-4  col-sm-4 ">
                <a href="{{route('admin',['type'=>'authors'])}}" class="btn @if(session()->get('typeAdmin')=='authors')  btnAdmAktivan @else btnAdmNeaktivan @endif">Rad sa autorima</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
        </div>
        <div class="p-xl-0 p-lg-0 p-md-2 p-sm-2 p-2"></div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12
        d-flex flex-xl-column flex-lg-column flex-md-row flex-sm-row flex-row">
            <div class="col-xl-12 col-lg-12 col-md-4 col-sm-4 ">
                <a href="{{route('admin',['type'=>'genres'])}}" class="btn @if(session()->get('typeAdmin')=='genres')  btnAdmAktivan @else btnAdmNeaktivan @endif">Rad sa zanrovima</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
            <div class="col-xl-12 col-lg-12 col-md-4  col-sm-4 ">
                <a href="{{route('admin',['type'=>'users'])}}" class="btn @if(session()->get('typeAdmin')=='users')  btnAdmAktivan @else btnAdmNeaktivan @endif">Rad sa korisnicima</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
            <div class="col-xl-12 col-lg-12 col-md-4 col-sm-4 ">
                <a href="{{route('admin',['type'=>'email'])}}" class="btn @if(session()->get('typeAdmin')=='email')  btnAdmAktivan @else btnAdmNeaktivan @endif">Pregled mejlova</a>
            </div>
            <div class="p-xl-2 p-lg-2 p-md-0 p-sm-0"></div>
        </div>


    </div>
    <div id="adminStrana" class="p-5 col-xl-10 col-lg-9 col-md-12 col-sm-12 col-12">
        @yield('contentAdmin')
    </div>
</div>
@include('fixed.footer')

<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>

@if(session('typeAdmin')=='statistics')
    <script src="{{asset('assets/js/adminJs/statistics.js')}}"></script>
@endif

@if(session('typeAdmin')=='users')
    <script src="{{asset('assets/js/adminJs/users.js')}}"></script>
@endif
</body>

</html>

