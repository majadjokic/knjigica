<!DOCTYPE html>
<html lang="sr">
@include('fixed.head')
<body>

@include('fixed.menu')
@yield('content')
@include('fixed.footer')
@include('fixed.javascripts')
</body>
</html>
