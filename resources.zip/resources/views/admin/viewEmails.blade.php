@extends('layouts.layoutAdmin')

@section('description')
   Admin- view emails
@endsection

@section('keywords')
    admin, view emails
@endsection

@section('title')
    Knjigica - Pregled emailova
@endsection

@section('contentAdmin')
    <div id="pregledMejlova">
        <h2>Pregled mejlova</h2>
        <div class="p-3"></div>
        <div class="row d-flex">

            @foreach($notRepliedTo as $en)
            <div class="p-1 col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 rounded">
                <div class="row d-flex justify-content-center col-12 emailBlok rounded  border border-dark">
                    <div class="prozirniSlojMejl row pt-2 col-12 border-bottom border-dark">
                        <p>Od: {{$en->first_name}} {{$en->last_name}}</p>
                    </div>
                    <div class="prozirniSlojMejl row pt-2 col-12 d-flex border-bottom border-dark">
                        <p>Email: {{$en->email}}</p>
                    </div>
                    <div class="prozirniSlojMejl row pt-2 col-12 d-flex border-bottom border-dark">
                        <p>Datum: {{$en->date}} - {{$en->time}}</p>
                    </div>
                    <div class="row pt-2 col-12">
                        <p>{{$en->text_mail}}</p>
                    </div>
                </div>
            </div>
            @endforeach


        </div>

    </div>


@endsection


