
@extends('layouts.layoutAdmin')

@section('description') Admin-enable @endsection
@section('keywords') admin,enable @endsection
@section('title') Admin - Vrati proizvod @endsection




@section('contentAdmin')

    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h1>Da li želiš da aktiviraš izabrano: {{$toEnName}}</h1>
        <br/>
        <form action="{{route($whereYes)}}" method="POST">
            @csrf
            <input type="hidden" name="toEn" value="{{$toEnId}}">
            <button  type="submit" class="btn dajBoju" >Da, želim.</button>
        </form>
        <br/>
        <a href="{{route('admin',['type'=>$whereNo])}}" class="btn">Ne, ne želim.</a>
    </div>


@endsection
