

@extends('layouts.layoutAdmin')

@section('description') Knjigica, online prodavnica knjiga. Detalji knjige. @endsection
@section('keywords') prodavnica, online kupovina, knjiga, knjige, knjizara @endsection
@section('title') Admin - Izmeni proizvod @endsection



@section('contentAdmin')

    <div>
        <h2><a href="{{route('admin',['type'=>'users'])}}" class="bojaLink">< Nazad na prethodnu stranicu</a></h2>
    </div>
    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>


    @if ($errors->any()||session()->has('admUsernameW')||session()->has('admEmailW')||session()->has('admPasswordW')||session()->has('admPasswordOldW'))
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
                @if(session()->has('admUsernameW'))
                    <li>{{ session('admUsernameW') }}</li>
                @endif
                @if(session()->has('admEmailW'))
                    <li>{{ session('admEmailW') }}</li>
                @endif
                @if(session()->has('admPasswordW'))
                    <li>{{ session('admPasswordW') }}</li>
                @endif
                    @if(session()->has('admPasswordOldW'))
                        <li>{{ session('admPasswordOldW') }}</li>
                    @endif
            </ul>
        </div>
    @endif
    <div>
    <h2>Izmeni osnovne podatke admina</h2>
    <br/>
    <form action="{{route('upAdminGo')}}" method="POST" name="upAdmin">
        @csrf
        @foreach($upAdmin as $a)
            <input type="hidden" name="idToUp" value="{{$a->id}}">
        <input class="form-control" type="text" name="firstName" placeholder="Ime" value="{{$a->first_name}}">
        <br/>
        <input class="form-control" type="text" name="lastName" placeholder="Prezime" value="{{$a->last_name}}">
        <br/>
        <input class="form-control" type="text" name="username" placeholder="Username" value="{{$a->username}}">
        <br/>
        <input class="form-control" type="email" name="email" placeholder="Email" value="{{$a->email}}">
        <br/>
        @endforeach
        <button class="btn" type="submit" name="btnUpAdmin">Izmeni podatke admina</button>
    </form>
    </div>

    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2>Izmeni lozinku admina</h2>
        <br/>
        <form action="{{route('upAdminPasswordGo')}}" method="POST" name="upAdminPassword">
            @csrf
            @foreach($upAdmin as $a)
                <input type="hidden" name="idToUp" value="{{$a->id}}">
                <input type="hidden" name="username" value="{{$a->username}}">
                <input class="form-control" type="password" name="passwordOld" placeholder="Stara lozinka">
                <br/>
                <input class="form-control" type="password" name="password" placeholder="Lozinka">
                <br/>
                <input class="form-control" type="password" name="passwordConf" placeholder="Potvrdi lozinku">
                <br/>
            @endforeach
            <button class="btn" type="submit" name="btnUpAdminPass">Izmeni lozinku admina</button>
        </form>
    </div>
    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2><a href="{{route('admin',['type'=>'users'])}}" class="bojaLink">< Nazad na prethodnu stranicu</a></h2>
    </div>

@endsection

