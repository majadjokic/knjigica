
@extends('layouts.layoutAdmin')

@section('description') Admin-disable @endsection
@section('keywords') admin,disable @endsection
@section('title') Admin - Povuci sa sajta @endsection




@section('contentAdmin')


    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h1>Da li želiš da deaktiviraš izabrano: {{$toDisName}}</h1>
        <br/>
        <form action="{{route($whereYes)}}" method="POST">
            @csrf
            <input type="hidden" name="toDis" value="{{$toDisId}}">
            <button  type="submit" class="btn dajBoju" >Da, želim.</button>
        </form>
        <br/>
        <a href="{{route('admin',['type'=>$whereNo])}}" class="btn">Ne, ne želim.</a>
    </div>


@endsection
