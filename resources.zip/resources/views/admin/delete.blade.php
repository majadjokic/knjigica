
@extends('layouts.layoutAdmin')

@section('description') Admin-delete @endsection
@section('keywords') admin,delete @endsection
@section('title') Admin - Obrisi proizvod @endsection



@section('contentAdmin')

    <div class="container col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h1>Da li želiš da obrišeš izabrano: {{$toRemName}}</h1>
        <h1 class="text-danger">NAPOMENA: Nakon ove akcije nemoguće je povratiti ove podatke!!!</h1>
        <br/>
        <form action="{{route($whereYes)}}" method="POST">
            @csrf
            <input type="hidden" name="toRem" value="{{$toRemId}}">
            <button  type="submit" class="btn dajBoju" >Da, želim.</button>
        </form>
        <br/>
        <a href="{{route('admin',['type'=>$whereNo])}}" class="btn">Ne, ne želim.</a>
    </div>


@endsection

