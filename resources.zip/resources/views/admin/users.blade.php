@extends('layouts.layoutAdmin')

@section('description')
    admin users
@endsection

@section('keywords')
    admin, rad sa korisnicima
@endsection

@section('title')
    Knjigica - Admin
@endsection

@section('contentAdmin')
    <div>
        <h2>Aktivnosti korisnika</h2>
        <br/>
        <label for="datumZaAktKor">Izaberite datum za prikaz</label>
        <input type="date" class="form-control" name="datumAktKor" id="datumZaAktKor"/>
        <br/>
        <p id="infoAktKor"></p>
        <div class="table-responsive" id="activitiesUsersTable">

        </div>

    </div>

    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2>Aktivnosti admina</h2>
        <br/>
        <label for="datumZaAktAdm">Izaberite datum za prikaz</label>
        <input type="date" class="form-control" name="datumAktAdm" id="datumZaAktAdm"/>
        <br/>
        <p id="infoAktAdm"></p>
        <div  class="table-responsive" id="activitiesAdminsTable">

        </div>

    </div>

    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2>Svi korisnici (pregled)</h2>
        <br/>
        <div class="table-responsive" id="usersTable">
            <table class="table  table-striped">
                <thead>
                <tr>
                    <th scope="col">Ime</th>
                    <th scope="col">Prezime</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Deaktiviraj</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $u)
                    <tr>
                        <td>{{$u->first_name}}</td>
                        <td>{{$u->last_name}}</td>
                        <td>{{$u->username}}</td>
                        <td>{{$u->email}}</td>
                        @if($u->active!=0)
                            <td><a class="btn" href="{{route('admin',['type'=>'disUser','moreInfo'=>$u->id])}}">Deaktiviraj korisnika</a></td>
                        @else
                            <td><a class="btn" href="{{route('admin',['type'=>'enUser','moreInfo'=>$u->id])}}">Aktiviraj korisnika</a></td>
                        @endif
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

    </div>

    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2>Svi admini</h2>
        <br/>
        <a href="{{route('admin',['type'=>'addAdmin'])}}" class="btn">Dodaj admina</a>
        <br/>
        <div class="table-responsive" id="adminsTable">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Ime</th>
                    <th scope="col">Prezime</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Izmeni</th>
                    <th scope="col">Deaktiviraj</th>
                </tr>
                </thead>
                <tbody>
                @foreach($admins as $a)
                    <tr>
                        <td>{{$a->first_name}}</td>
                        <td>{{$a->last_name}}</td>
                        <td>{{$a->username}}</td>
                        <td>{{$a->email}}</td>

                        @if(session('userId')==$a->id)
                            <td><a class="btn" href="{{route('admin',['type'=>'upAdmin','moreInfo'=>$a->id])}}">Izmeni admina</a></td>
                        @else
                            <td><p>NEDOZVOLJENA AKCIJA</p></td>
                        @endif

                        @if(session('userId')!=$a->id&&$a->active!=0)
                        <td><a class="btn" href="{{route('admin',['type'=>'disAdmin','moreInfo'=>$a->id])}}">Deaktiviraj admina</a></td>
                            @elseif(session('userId')!=$a->id&&$a->active==0)
                                <td><a class="btn" href="{{route('admin',['type'=>'enAdmin','moreInfo'=>$a->id])}}">Aktiviraj admina</a></td>
                        @else
                        <td><p>NEDOZVOLJENA AKCIJA</p></td>
                        @endif
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

    </div>

       <br/>




@endsection
