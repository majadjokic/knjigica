@extends('layouts.layoutAdmin')

@section('description')
    admin statistics
@endsection

@section('keywords')
    admin, rad sa zanarovima
@endsection

@section('title')
    Knjigica - Admin
@endsection

@section('contentAdmin')
    <div id="radSaZanrovima">
        <div>
            @if ($errors->any()||session()->has('alreadyExistsG'))
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                            @if(session()->has('alreadyExistsG'))
                                <li>{{ session('alreadyExistsG') }}</li>
                            @endif
                    </ul>
                </div>
            @endif

                <div class="container-fluid">

                    <h2>Dodaj žanr</h2>
                    <form action="{{route('addGenre')}}" method="POST" name="addGenre">
                        @csrf
                        <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="genre" id="zanr">
                        <br/>
                        <button class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="submit" name="btnAddGenre" id="btnAddGenre">Dodaj žanr</button>
                    </form>
                </div>
        </div>


        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>


        <div>

            <div class="container-fluid">

                <h2>Izmeni žanr</h2>
                <form action="{{route('upGenre')}}" method="POST" name="upGenre">
                    @csrf
                    <p class="text-danger">Napomena: Ovde se nalaze svi žanrovi tj. i oni aktivni(vidljivi običnim korisnicima)
                        i oni neaktivni(nevidljivi običnim korisnicima).</p>
                    <select class="form-control" name="genreId">
                        <option value=0>Izaberi žanr za izmenu</option>
                        @foreach($allGenres as $g)
                            <option value={{$g->id}}>{{$g->genre}}</option>
                        @endforeach
                    </select>
                    <br/>
                    <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="genre" id="zanr">
                    <br/>
                    <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="submit" name="btnUpGenre" id="btnUpGenre">
                </form>

            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Aktivni žanrovi</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                {{--                GENRE--}}
                @foreach($activeGenres as $ag)
                    <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                        <h4>{{$ag->genre}}</h4>
                        <div class="p-2">
                            <a class="btn"
                               href="{{route('admin',['type'=>'disGen','moreInfo'=>$ag->id])}}">Deaktiviraj žanr</a>
                        </div>

                        <div class="p-2">
                            <a class="btn"
                               href="{{route('admin',['type'=>'delGen','moreInfo'=>$ag->id])}}">Obrisi žanr</a>
                        </div>
                    </div>
                @endforeach
                {{--                GENRE--}}
            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Neaktivni (skriveni) žanrovi</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                {{--                GENRE--}}
                @foreach($inactiveGenres as $gn)
                    <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                        <h4>{{$gn->genre}}</h4>
                        <div class="p-2">
                            <a class="btn"
                               href="{{route('admin',['type'=>'enGen','moreInfo'=>$gn->id])}}">Aktiviraj žanr</a>
                        </div>

                        <div class="p-2">
                            <a class="btn"
                               href="{{route('admin',['type'=>'delGen','moreInfo'=>$gn->id])}}">Obrisi žanr</a>
                        </div>
                    </div>
                @endforeach
                {{--                GENRE--}}
            </div>
        </div>

    </div>

@endsection

