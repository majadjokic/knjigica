@extends('layouts.layoutAdmin')

@section('description')
    admin statistics
@endsection

@section('keywords')
    admin, rad sa autorima
@endsection

@section('title')
    Knjigica - Admin
@endsection

@section('contentAdmin')
    <div id="radSaAutorima">
        <div>
            @if ($errors->any()||session()->has('alreadyExistsA'))
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                            @if(session()->has('alreadyExistsA'))
                                <li>{{ session()->get('alreadyExistsA') }}</li>
                            @endif
                    </ul>
                </div>
            @endif

            <div class="container-fluid">

                <h2>Dodaj autora</h2>
                <form action="{{route('addAuthor')}}" method="POST" name="addAuthor">
                @csrf
                <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="author" id="pisac">
                <br/>
                    <button class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="submit" name="btnAddAuthor" id="btnAddAuthor">Dodaj autora</button>
                </form>

            </div>
        </div>


        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>


        <div>

            <div class="container-fluid">

                <h2>Izmeni autora</h2>
                <form action="{{route('upAuthor')}}" method="POST" name="upAuthor">
                @csrf
                <p class="text-danger">Napomena: Ovde se nalaze svi autori tj. i oni aktivni(vidljivi običnim korisnicima)
                    i oni neaktivni(nevidljivi običnim korisnicima).</p>
                <select class="form-control" name="authorId">
                    <option value=0>Izaberi autora za izmenu</option>
                    @foreach($allAuthors as $a)
                        <option value={{$a->id}}>{{$a->author}}</option>
                    @endforeach
                </select>
                <br/>
                <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="author" id="pisac">
                <br/>
                    <button class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="submit" name="btnUpAuthor" id="btnUpAuthor">Izmeni autora</button>
                </form>

            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Aktivni autori</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
{{--                AUTOR--}}
                @foreach($activeAuthors as $aa)
                <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                    <h4>{{$aa->author}}</h4>
                    <div class="p-2">
                        <a class="btn"
                           href="{{route('admin',['type'=>'disAuth','moreInfo'=>$aa->id])}}">Deaktiviraj autora</a>
                    </div>

                    <div class="p-2">
                        <a class="btn"
                           href="{{route('admin',['type'=>'delAuth','moreInfo'=>$aa->id])}}">Obrisi autora</a>
                    </div>
                </div>
                @endforeach
{{--                AUTOR--}}
            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Neaktivni (skriveni) autori</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                {{--                AUTOR--}}
                    @foreach($inactiveAuthors as $an)
                        <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                            <h4>{{$an->author}}</h4>
                            <div class="p-2">
                                <a class="btn"
                                   href="{{route('admin',['type'=>'enAuth','moreInfo'=>$an->id])}}">Aktiviraj autora</a>
                            </div>

                            <div class="p-2">
                                <a class="btn"
                                   href="{{route('admin',['type'=>'delAuth','moreInfo'=>$an->id])}}">Obrisi autora</a>
                            </div>
                        </div>
                    @endforeach
                {{--                AUTOR--}}
            </div>
        </div>

    </div>

@endsection

