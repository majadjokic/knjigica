@extends('layouts.layoutAdmin')

@section('description')
    admin products
@endsection

@section('keywords')
    admin, rad sa proizvodima
@endsection

@section('title')
    Knjigica - Admin
@endsection

@section('contentAdmin')
    <div id="radSaProizvodima">
        <div class="container-fluid">
            <h2>Dodaj proizvod</h2>
            <p>Klikni na dole dugme da odeš na stranicu za dodaju proizvoda.</p>
            <a href="{{route('admin',['type'=>'addProd'])}}" class="btn">Dodaj proizvod</a>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Knjige u prodaji</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
{{--                KNJIGA--}}
                @foreach($titlesForSale as $t4s)
                <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="col-12"><img class="col-12" src="{{asset('assets/img/proizvodi/'.$t4s->cover)}}"></div>
                    <p>{{$t4s->title}}</p>
                    <div class="col-12">
                        <div class="p-2">
                            <a class="btn" href="{{route('admin',['type'=>'upProd','moreInfo'=>$t4s->id])}}">Izmeni proizvod</a>
                        </div>

                        <div class="p-2">
                            <a class="btn" href="{{route('admin',['type'=>'disProd','moreInfo'=>$t4s->id])}}">Povuci proizvod iz prodaje</a>
                        </div>

                        <div class="p-2">
                            <a class="btn" href="{{route('admin',['type'=>'delProd','moreInfo'=>$t4s->id])}}">Obrisi proizvod</a>
                        </div>

                    </div>
                </div>
                @endforeach
{{--                KNJIGA--}}


            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

        <div class="container-fluid">
            <div class="container-fluid">
                <h1>Knjige povucene iz prodaje</h1>
            </div>
            <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                @foreach($titlesNotForSale as $tn4s)
                    <div class="p-5 col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="col-12"><img class="col-12" src="{{asset('assets/img/proizvodi/'.$tn4s->cover)}}"></div>
                        <p>{{$tn4s->title}}</p>
                        <div class="col-12">
                            <div class="p-2">
                                <a class="btn" href="{{route('admin',['type'=>'upProd','moreInfo'=>$tn4s->id])}}">Izmeni proizvod</a>
                            </div>

                            <div class="p-2">
                                <a class="btn" href="{{route('admin',['type'=>'enProd','moreInfo'=>$tn4s->id])}}">Vrati proizvod u prodaju</a>
                            </div>

                            <div class="p-2">
                                <a class="btn" href="{{route('admin',['type'=>'delProd','moreInfo'=>$tn4s->id])}}">Obrisi proizvod</a>
                            </div>

                        </div>
                    </div>
                @endforeach


            </div>
        </div>

    </div>

@endsection
