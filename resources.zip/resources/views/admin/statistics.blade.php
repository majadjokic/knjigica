@extends('layouts.layoutAdmin')

@section('description')
    admin statistics
@endsection

@section('keywords')
    admin, site statistics
@endsection

@section('title')
    Knjigica - Admin
@endsection

@section('contentAdmin')
    <div id="statistikaSajta">

        <div>
            <h2>Broj poseta stranicama</h2>
            <br/>
                <label for="datumZaBrPoseta">Izaberite datum za prikaz</label>
                <input type="date" class="form-control" name="datumBrPoseta" id="datumZaBrPoseta"/>
            <br/>
            <p id="infoDateVis"></p>
            <div  class="table-responsive" id="visitsTable">

            </div>
        </div>

        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>
        <div><h2>Broj i spisak kupovima (po mesecu)</h2>
            <div>
                <label for="mesecZaBrKupovina">Izaberite mesec za prikaz</label>
                <select class="form-control" name="mesecBrKupovina" id="mesecZaBrKupovina">
                    <option value=0>Mesec</option>
                    <option value=1>Januar</option>
                    <option value=2>Februar</option>
                    <option value=3>Mart</option>
                    <option value=4>April</option>
                    <option value=5>Maj</option>
                    <option value=6>Jun</option>
                    <option value=7>Jul</option>
                    <option value=8>Avgust</option>
                    <option value=9>Septembar</option>
                    <option value=10>Oktobar</option>
                    <option value=11>Novembar</option>
                    <option value=12>Decembar</option>
                </select>
                <label for="godinaZaBrKupovina">Izaberite godinu za prikaz</label>
                <select class="form-control" name="godinaBrKupovina" id="godinaZaBrKupovina">
                    <option value=0>Godina</option>
                    <option value=2021>2021</option>
                    <option value=2022>2022</option>
                    <option value=2023>2023</option>
                    <option value=2024>2024</option>
                    <option value=2025>2025</option>
                </select>
            </div>
            <br/>
            <p id="infoDateOrd"></p>
            <br/>
            <h4 id="brojKupovina"></h4>
            <h4 id="zaradaZaMesec"></h4>
            <div  class="table-responsive" id="ordersTable">

            </div>


        </div>
        <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>
        <br/>
        <div>
            <h1>Najprodavaniji proizvodi</h1>
            <div id="najprodavanijeGrafikonADMIN" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12
            d-flex flex-xl-row flex-lg-row flex-md-column flex-sm-column flex-column">
                @foreach($top3 as $t3)
                    <div class="d-flex flex-column col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 p-2">
                        <div class="col-12 p-3 d-flex justify-content-center align-content-center">
                            <div class="col-12 d-block">
                                <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-6  position-absolute z-2">
                                    <img src="
                            @if($t3->num_row==1)
                                {{asset('assets/img/gold.png')}}
                                @elseif($t3->num_row==2)
                                {{asset('assets/img/silver.png')}}
                                @else
                                {{asset('assets/img/bronze.png')}}
                                @endif
                                        " class="col-xl-4 col-lg-3 col-md-6 col-sm-5 col-4">
                                </div>
                                <div class="col-12 z-1 p-4">
                                    <a href="{{route('product',['id'=>$t3->id])}}">
                                        <img class="col-12" src="{{asset('assets/img/proizvodi/'.$t3->cover)}}"></a>
                                </div>

                            </div>
                        </div>
                        <div class="col-12 pt-2">
                            <div class="d-flex flex-row col-12">
                                <div class="col-12 flex-column">
                                    <h3>Prodato {{$t3->soled}} primeraka</h3>
                                    <h4>{{$t3->title}}</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

            </div>

            <br/>
            <br/>
            <div id="najprodavanijeTabela" class="col-12">
                <h2>Ostali proizvodi</h2>
                <div  class="table-responsive">
                <table class="table table-responsive table-striped">
                    <thead>
                    <tr>
                        <th scope="col">Mesto na listi</th>
                        <th scope="col">Naslov</th>
                        <th scope="col">Broj prodatih primeraka</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($topProd as $t)
                        <tr>
                            <td>{{$t->num_row}}</td>
                            <td>{{$t->title}}</td>
                            <td>{{$t->soled}}</td>
                        </tr>
                    @endforeach

                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>

@endsection

