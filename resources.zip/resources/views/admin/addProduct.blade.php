
@extends('layouts.layoutAdmin')

@section('description') Knjigica, online prodavnica knjiga. Detalji knjige. @endsection
@section('keywords') prodavnica, online kupovina, knjiga, knjige, knjizara @endsection
@section('title') Admin - Dodaj proizvod @endsection



@section('contentAdmin')

    <div>
        <h2><a href="{{route('admin',['type'=>'products'])}}" class="bojaLink">< Nazad na pregled proizvoda</a></h2>
    </div>
    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div class="container d-flex flex-column col-xl-12">
        <h3>Pre nego što počnete da popunjavate formu za dodavanja proizvoda, proverite da
            li postoje autori/žanrovi koji odgovaraju za taj proizvod.</h3>
        <br/>
            <select class="form-select col-xl-6">
                <option value="0">Svi autori</option>
                @foreach($authors as $a)
                    <option value={{$a->id}}>{{$a->author}}</option>
                @endforeach
            </select>
            <br/>
            <select class="form-select col-xl-6">
                <option value="0">Svi žanrovi</option>
                @foreach($genres as $g)
                    <option value={{$g->id}}>{{$g->genre}}</option>
                @endforeach
            </select>

        <br/>
        <h3>Nema određenog autora? <a href="{{route('admin',['type'=>'authors'])}}" class="bojaLink">Idi na dodavanje autora</a></h3>
        <h3>Nema određenog žanra? <a href="{{route('admin',['type'=>'genres'])}}" class="bojaLink">Idi na dodavanje žanrova</a></h3>
        <h3 class="text-danger">Napomena: Moguće je da traženi autori/žanrovi postoje nego da su deaktivirani.
            Proverite deo stranice sa neaktivnim autorima/žanrovima.</h3>
    </div>
    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
                @if(session()->has('alreadyExistsP'))
                        <li>{{ session('alreadyExistsP') }}</li>
                    @endif
            </ul>
        </div>
    @endif

    <div class="col-xl-12 p-3">
        <h2>Dodaj proizvod</h2>
        <br/>
        <form action="{{route('addProdGo')}}" method="POST" name="addProduct" enctype="multipart/form-data">
            @csrf
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="title" id="title" placeholder="Naslov"  value="{{old('title')}}">
            <br/>
            <textarea class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12"  name="desc" id="desc" placeholder="Opis"   value="{{old('desc')}}"></textarea>
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="formatA" id="formatA" placeholder="Format (pr. 13x20 cm)"   value="{{old('formatA')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="numPages" id="numPages" placeholder="Broj strana"   value="{{old('numPages')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="letter" id="letter" placeholder="Pismo"   value="{{old('letter')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="coverType" id="coverType" placeholder="Tip korica"   value="{{old('coverType')}}">
            <br/>
            <label for="published">Izdato (datum)</label>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="date" name="published" id="published"   value="{{old('published')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="isbn" id="isbn" placeholder="ISBN (pr. 978-86-521-4404-4)"   value="{{old('isbn')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="translator" id="translator" placeholder="Prevodilac"   value="{{old('translator')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="text" name="price" id="price" placeholder="Cena"   value="{{old('price')}}">
            <br/>
            <input class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="file" id="cover" name="cover">
            <br/>
            <label class="font-weight-bold" for="authors">Pisac/pisci</label>
            <div name="authors">
                @foreach($authors as $a)
                    <div class="d-flex flex-row">
                        <input type="checkbox" name="author[]" id="pisac{{$a->id}}"
                               value={{$a->id}}
                               @if(old('authors')&&in_array($a->id,old('authors')))
                                   checked
                            @endif
                        >
                        <label for="pisac{{$a->id}}">{{$a->author}}</label>
                    </div>
                @endforeach
            </div>
            <br/>
            <label class="font-weight-bold" for="genres">Žanr/žanrovi</label>
            <div name="genres">
                @foreach($genres as $g)
                    <div class="d-flex flex-row">
                        <input type="checkbox" name="genre[]" id="zanr{{$g->id}}"
                               value={{$g->id}}
                               @if(old('genres')&&in_array($g->id,old('genres')))
                                   checked
                            @endif
                        >
                        <label for="zanr{{$g->id}}">{{$g->genre}}</label>
                    </div>
                @endforeach
            </div>
            <br/>
            <button class="form-control col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12" type="submit" id="btnADP" name="btnADP">Dodaj proizvod</button>
        </form>
    </div>

    <div class="pt-5 pb-5"><hr style="border-top: dotted 10px;" /></div>

    <div>
        <h2><a href="{{route('admin',['type'=>'products'])}}" class="bojaLink">< Nazad na pregled proizvoda</a></h2>
    </div>



@endsection
