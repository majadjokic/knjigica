@extends('layouts.layout')

@section('description')
    Knjigica, online prodavnica knjiga.
@endsection
@section('keywords')
    prodavnica, online kupovina, knjizara, pocetna
@endsection

@section('title')
    Knjigica - Pocetna
@endsection

@section('content')

    <div id="bgImg" class="container-fluid p-5 d-flex justify-content-center">
        <div class="dajBoju col-xl-12 col-lg-12 col-md-9 col-sm-12 col-12 d-flex
        flex-column justify-content-center p-5">
            <div class="container-fluid d-flex justify-content-center">
                <h1>Naša TOP 3 bestseller-a</h1>
            </div>
            <div id="najprodavanijeGrafikon" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12
            d-flex flex-xl-row flex-lg-row flex-md-column flex-sm-column flex-column">
                @for($i=0;$i<3;$i++)
                <div class="d-flex flex-column col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 p-2">
                    <div class="col-12 p-3 d-flex justify-content-center align-content-center">
                        <div class="col-12 d-block">
                            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-6  position-absolute z-2">
                                <img src="
                            @if($i==0)
                                {{asset('assets/img/gold.png')}}
                                @elseif($i==1)
                                {{asset('assets/img/silver.png')}}
                                @else
                                {{asset('assets/img/bronze.png')}}
                                @endif
                                    " class="col-xl-4 col-lg-3 col-md-6 col-sm-5 col-4">
                            </div>
                            <div class="col-12 z-1 p-4">
                                <a href="{{route('product',['id'=>$top[$i]->id])}}"><img class="col-12" src="{{asset('assets/img/proizvodi/'.$top[$i]->cover)}}"></a>
                            </div>

                        </div>
                    </div>
                    <div class="col-12 pt-2">
                        <div class="d-flex flex-row col-12">
                            <div class="col-12 flex-column">
                                <h4>{{$top[$i]->title}}</h4>
                            </div>
                        </div>
                    </div>
                </div>
                @endfor
            </div>
            <br/>
            <div class="container-fluid d-flex justify-content-center">
                <h3><a href="{{route('products')}}" class="btn">Pogledajte i ostale naslove koje imamo u ponudi!</a></h3>
            </div>
        </div>
    </div>



@endsection


