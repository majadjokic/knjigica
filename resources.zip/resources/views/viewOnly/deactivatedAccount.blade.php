<!DOCTYPE html>
<html lang="sr">
@section('description')
    Banned
@endsection
@section('keywords')
    prodavnica, online kupovina, knjizara, banned
@endsection
@section('title')
    BANOVANI STE
@endsection
@include('fixed.head')
<body>

<div class="container-fluid">
    <div class="p-5">
        <div class="p-5 d-flex justify-content-center align-items-center flex-column">
            <div class="col-6">
                <img src="{{asset('assets/img/knjigica.png')}}" alt="Knjigica logo" class="col-12"/>
            </div>
            <div class="p-5">
                <h1>Ups! Ovaj nalog je banovan.</h1>
            <br>

            </div>
        </div>
    </div>

</div>



<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>

</body>
</html>
