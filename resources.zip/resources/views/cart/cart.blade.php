@extends('layouts.layout')

@section('description')
    cart
@endsection

@section('keywords')
   cart
@endsection

@section('title')
    Knjigica - Korpa
@endsection

@section('content')

@if($cart=="none")
<div  class="container-fluid d-flex flex-column justify-content-cener align-items-center p-5">
{{--    <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center align-items-center">--}}
        <h3>Trenutno nemate nijedan proizvod u korpi.</h3>
{{--    </div>--}}
{{--    <div class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center align-items-center">--}}
        <h4><a href="{{route('products')}}" class="bojaLink">Pogledajte proizvode</a></h4>
{{--    </div>--}}

</div>
@else



<div class="table-responsive" id="tabelaCart">
    <table class="table table-striped table-hover">
{{--        table-dark table-bordered--}}
        <thead>
        <tr>
            <th scope="col">
                Proizvod
            </th>
            <th scope="col">
                Slika
            </th>
            <th scope="col">
                Cena (jednog komada)
            </th>
            <th scope="col">
                Količina
            </th>
            <th scope="col">
                Izbacite proizvod
            </th>
        </tr>
        </thead>
        <tbody>
        @foreach($cart as $c)
                <tr>
                    <td>{{$c->title}}</td>
                    <td><div style="width:150px"><img class="col-12" src="{{asset('assets/img/proizvodi/'.$c->cover)}}" alt="{{$c->title}}"></div></td>
                    <td>{{$c->prod_price}}</td>
                    <td><div class="d-flex flex-row justify-content-around" width="200">
                            <form action="{{route('removeQ')}}" method="POST" name="minusKol">
                                @csrf
                                <input type="hidden" name="minusProd" value={{$c->prod_id}}>
                                <input type="hidden" name="minusCart" value={{$c->cart_id}}>
                                <input type="hidden" name="minusNum" value=1>
                                <input class="btn text-light" type="submit" name="btnMinus" id="btnMinus" value="<">
                            </form>
                        {{$c->num_of_prod}}
                            <form action="{{route('addQ')}}" method="POST" name="plusKol">
                                @csrf
                                <input type="hidden" name="plusProd" value={{$c->prod_id}}>
                                <input type="hidden" name="plusCart" value={{$c->cart_id}}>
                                <input type="hidden" name="plusNum" value=1>
                                <input class="btn text-light" type="submit" name="btnPlus" id="btnPlus" value=">">
                            </form>
                        </div>
                    </td>
                    <td>
                        <form action="{{route('removeProd')}}" method="POST" name="izbaci">
                            @csrf
                            <input type="hidden" name="removeProd" value={{$c->prod_id}}>
                            <input type="hidden" name="removeCart" value={{$c->cart_id}}>
                            <input class="btn text-light" type="submit" name="btnIzbaci"  id="btnIzbaci" value="Izbaci">
                        </form>
                    </td>
                </tr>

        @endforeach
        </tbody>
    </table>
</div>
    <div class="row p-3 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex flex-column align-content-end">
{{--        <div class="row d-flex justify-content-end">--}}
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <h5>UKUPNA CENA KORPE: {{$total}} RSD</h5>
            </div>
{{--        </div>--}}
{{--        <div class="row d-flex ">--}}
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
            <form class="p-3" action="{{{route('checkOut')}}}" method="get">
                @csrf
                <input type="hidden" name="cartId" value="{{$cartId}}">
                <button type="submit" class="btn">Idi na kasu</button>
            </form>
        </div>

{{--            <a href="#" class="btn"><h5>Idi na kasu</h5></a>--}}
{{--        </div>--}}
{{--        <div class="p-1"></div>--}}

    </div>


@endif

@endsection
