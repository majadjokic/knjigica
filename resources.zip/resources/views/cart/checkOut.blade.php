@extends('layouts.layout')

@section('description') Knjigica, online prodavnica knjiga. Ovde su proizvodi koje ste stavili u korpu. @endsection
@section('keywords') prodavnica, online kupovina, kupi @endsection
@section('title') Knjigica - Kasa @endsection

@section('content')

        <div class="container-fluid d-flex flex-xl-row flex-lg-row flex-md-column flex-sm-column p-5">

            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">


                <div class="container-fluid">
                    <h3>Sadrzaj korpe</h3>
                </div>
                <div class="table-responsive" id="tabelaCart">
                    <table class="table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>
                                Proizvod
                            </th>
                            <th>
                                Cena (jednog komada)
                            </th>
                            <th>
                                Količina
                            </th>
                            <th>
                                Ukupna cena
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($cartList as $c)
                             <tr>
                                <td>{{$c->title}}</td>
                                <td>{{$c->prod_price}} RSD</td>
                                <td>{{$c->num_of_prod}}</td>
                                <td>
                                    {{$c->total}} RSD
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <h4>UKUPNA CENA KORPE: {{$cartPrice}} RSD</h4>
                </div>
            </div>
            <div class="p-xl-0 p-lg-0 p-md-3 p-sm-3"></div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <h2>Kasa</h2>
            @if ($errors->any()||session()->has('cardWrong'))
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                        @if(session()->has('cardWrong'))
                                <li>{{ session('cardWrong') }}</li>
                            @endif
                    </ul>
                </div>
            @endif

            <form action="{{route('checkOutGo')}}" id="checkoutForm" name="checkoutForm" method="post">
                @csrf
                <input type="hidden" name="cartId" value={{$cartId}}>
                <div class="d-flex flex-column justify-content-center align-items-center flex-column">
                    <div class="d-flex flex-column col-xl-12 col-lg-12 col-md-12 col-sm-12 p-2">
                        <p>Način plaćanja</p>
                        <div class="d-flex flex-row align-items-center col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <input type="radio" name="paymentMethod" id="npPoPouzecu" value="pouzece">
                            <label for="npPoPouzecu">Po pouzeću</label>
                        </div>
                        <div class="d-flex flex-row align-items-center col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <input type="radio" name="paymentMethod" id="npKartica" value="kartica">
                            <label for="npKartica">Kartica</label>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-2">
                        <p>Broj kartice (ako placate karticom)</p>
                        <input type="text" class="form-control" name="card" id="kartica">
                    </div>

                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-2">
                        <p>Država</p>
                        <select class="form-control" name="country">
                            <option value=0>Drzava</option>
                            @foreach($countries as $d)
                                <option value={{$d->id}}>{{$d->country}}</option>
                            @endforeach

                        </select>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-2">
                        <p>Grad</p>
                        <input type="text" class="form-control" name="city" id="grad">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-2">
                        <p>Adresa</p>
                        <input type="text" class="form-control" name="address" id="adresa">
                    </div>

                    <div class="d-flex justify-content-center">
                        <button class="btn p-2 m-3" type="submit" name="btnCHO" id="btnCHO" >Završite kupovinu</button>
                    </div>
                    <div class="d-flex justify-content-center">
                        <a class="bojaLink" href="{{route('cart')}}">Predomislili ste se? Vratite se na korpu.</a>
                    </div>
                </div>
            </form>
            </div>

        </div>

@endsection


